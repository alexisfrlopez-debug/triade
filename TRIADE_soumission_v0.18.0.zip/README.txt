TRIADE — ÉDITION ACADÉMIQUE v0.18.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.18.0.pdf    — le manuscrit : LA VAGUE 5 DES
     RÉVISIONS (l'édition de la consolidation) — les dix instructions du
     réviseur exécutées une à une, chacune avec son étape de vérification :
     (1) RQ2 UNIFIÉ SOUS PÉRIMÈTRES DOCUMENTÉS — les médianes courantes
     1 277/3 374/3 674 (le round-trip instrumenté au tokenizer natif, le
     plan pré-enregistré ede70035), les valeurs v0.14.0 et M1 étiquetées
     historiques, les ratios baseline recalculés (235×/82×), la
     décomposition par catégorie confirmée par re-tokenisation
     indépendante (zéro écart au-delà d'un token) ;
     (2) LES SIGNES DE §3.5 CORRIGÉS (+9,9 % contre -O2, −2,0 % contre
     -Os, la convention explicite, le linter étendu aux signes) ;
     (3) LA CAMPAGNE RÉCONCILIÉE — la table complète des 22 livraisons
     (tab:campagne) générée des ledgers, le 7e rouge explicite (l'artefact
     du juge), M3 au carnet (104/17 min), les CINQ verdicts explicites
     (H1 tenue, H2 tenue, H3 falsifiée, H4-D204 tenue, H5 falsifiée) ;
     (4) LES QUATRE RÉFÉRENCES VÉRIFIÉES AUX SOURCES PRIMAIRES (STOKE
     ASPLOS 2013 ; SuperCoder arXiv:2505.11480 ; LaaC IJCNN 2025 ;
     Nova ICLR 2025), la citation cassée guérie ;
     (5) LE LEMME DE COUVERTURE ÉNONCÉ ET DÉCHARGÉ (SMT, contrôles
     négatifs), L'ALIGNEMENT TLA+ RÈGLE PAR RÈGLE (13/13), la batterie
     TLC/Apalache re-jouée 8/8 ;
     (6) LA CONFORMITÉ GÉNÉRATIVE RAPPORTÉE — 10 000 traces, 660 écarts
     d'UNE classe (la garde du modèle canonique-seule), le rejeu
     bit-identique vérifié deux fois ;
     (7) LE DUDECT REFORMULÉ EN ÉGALITÉ EXACTE (six comptes uniques,
     x25519 1 238 959 confirmé, la faute v110 nommée) ET LES RUNS
     MATÉRIELS kit-2 INTÉGRÉS (N=200/N=400, témoins signés) ;
     (8) LA MENACE « KIT PARTAGÉ ET FORMATS ASYMÉTRIQUES » (§5) avec
     l'analyse de sensibilité et le plan d'extension D210 pré-enregistré ;
     (9) LA LICENCE OUVERTE À L'ÉVALUATION (D209 : le Additional Use
     Grant académique appliqué, date d'effet 17/11/2026) ;
     (10) M4 OPTIMISÉ SANS AUCUN CONTRÔLE RETIRÉ — 50,9 s → 39,3/39,2 s
     (deux exécutions, consoles identiques, scellés intacts, C re-mesuré
     2,2 s sur la même machine : 23,1× → 17,9×, H5 demeure falsifiée) ;
  3. tableaux_donnees_v0.18.0.csv    — les tableaux de données (les
     sources brutes consolidées : la re-mesure RQ2, la campagne, les
     traces exactes, la M4) ;
  4. empreintes_livrables.txt        — les SHA-256 des livrables et des
     pièces scellées (chaque empreinte vérifiée sur les octets) ;
  5. rapport_verification_v0.18.0.txt — l'étape de vérification (douze
     points, chacun VERT sur pièces).

LA LICENCE : Business Source License 1.1, Additional Use Grant
ACADÉMIQUE (peer review, artifact evaluation, réplication scientifique,
usage non commercial — D209, en vigueur au 17/11/2026 ; Change Date
2030-10-28 → GPLv3+).

LE DÉPÔT : github.com/alexisfrlopez-debug/triade (le miroir public).
