TRIADE — LE COMPLET DE L'ÉDITION v0.25.0 (la vague 18, 24 novembre 2026)
========================================================================

Sources des cinq pièces (edition-v0230/, scripts/spec_v158/, scripts/livre_v18/),
packs (pack-v250/ et les précédents pour l'histoire), ateliers des vagues 15 à 18,
plans gelés de la vague 18 et leurs empreintes, scripts de la vague 18 (garde du
prescriptif, linter v2 porté, kit TPM, expansion structurée), paquet de réplication,
instructions exécutées (vagues 17 et 18), journal des décisions, worklog (Entrées
398-400), REPRISE et OU-TROUVER à l'état du 24/11.

CE QUE PORTE LA VAGUE 18 : les cinq aléas du rendez-vous (D261), la liste blanche
fermée du prescriptif (D262), le compteur NV TPM 2.0 (D263), l'expansion structurée
avec réparation bornée (D264), le linter d'édition v2 porté et les résidus soldés
(D265). Les pièces : manuscrit v0.25.0, spec v0.15.10, Livre v1.9, preuves et
présentation v0.25.0.

LIMITES NOMMÉES : métal nu (≥ 2 machines), TPM réel, campagne à structured output,
linter intégral (1 991 tokens) ; aucun chiffre fabriqué.

DOIS : protocole (à la publication de cette édition) · corpus v2.1 10.5281/zenodo.24479882 ·
entraînement 10.5281/zenodo.24495492 · kit développeur 10.5281/zenodo.24495696.
AUCUN SECRET : ni couche I signée, ni carte C, ni clé, ni phrase de contrôle.
