TRIADE — ÉDITION ACADÉMIQUE v0.19.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.19.0.pdf    — le manuscrit : LA CLÔTURE DE LA
     CAMPAGNE D210 (l'édition finale du cycle) — le PDF portant la
     clôture de l'extension D210, la lecture de l'attribution empirique
     et les lignes M3 : les QUATRE unités closes aux formats identiques
     (loupe-02 VERT, loupe-08 VERT, loupe-13 VERT, loupe-16 ROUGE à la
     cap — trois échappées comptées, toutes côté kit dans le juge
     partagé, la pièce jamais fautive), l'attribution tranchée sur
     pièces (la même pièce C re-livrée via un kit standard minimal :
     14 VERT 0 ROUGE — le flux compilé pur ne l'aurait pas produite),
     les verdicts H6--H8 explicites (H6 tenue par attribution ; H7 non
     testée — le tirage public ne donna aucun contraste, l'hypothèse
     reportée ; H8 réfutée — 51 %/39 %/9 %, une unité sur quatre
     au-dessus du seuil inscrit), les métriques M2/M3/M4 telles que
     consignées (la couture de la première unité nommée ; le gap M2 de
     l'attribution jamais reconstruit ; l'écart M3 des bornes du
     carnet — les lignes reçues telles quelles) ; AUCUNE valeur mesurée
     de la v0.18.1 scellée n'est modifiée — la v0.19.0 est purement
     additive (30 pages) ;
  3. empreintes_livrables.txt        — les sha256 de chaque pièce du
     dépôt, la pièce scellée loupe.exe 0.1.1 et le scellé proxy.exe
     compris (le registre fait foi) ;
  4. rapport_verification_v0.19.0.txt — la vérification V1--V10 sur
     pièces (la compilation, le linter 35/35, la falsification prouvée
     — trois mutations, trois refus —, la réconciliation 10/10, le
     contrôle géométrique, les écarts nommés) ;
  5. tableaux_donnees_v0.19.0.csv    — les données : le round-trip
     instrumenté RQ2 (les mesures brutes, le plan pré-enregistré), la
     table de campagne D204 (22 livraisons) et la table D210 née (7
     livraisons, générée du registre), le carnet M3 au geste.

Licence : Business Source License 1.1 avec Additional Use Grant
académique (peer review, artifact evaluation, réplication scientifique,
recherche non commerciale — la décision D209 ; Change Date 2030-10-28,
conversion GPLv3+).
