TRIADE — LE COMPLET DE L'ÉDITION v0.24.0 (la vague 17, 24 novembre 2026)
========================================================================

L'archive complète du dépôt à l'édition v0.24.0 : les sources des cinq pièces
(edition-v0230/ pour le manuscrit, scripts/spec_v158/ pour la spécification,
scripts/livre_v18/ pour le Livre), le pack des cinq pièces (pack-v240/), les ateliers
de la vague 17 (ateliers-vague17/ : W17R1D81, W17R2PAT, W17R3R10, W17R4PER), le
paquet de réplication public (replication-v17/), les scripts de la vague (scripts/vague17
et vague17/), les instructions exécutées (instructions_vague17_20261124/) et le rapport
de vérification (rapport_verification_v0.24.0.txt).

CE QUE PORTE L'ÉDITION : la spécification §7.1.1 (atomicité bornée à huit octets naturels,
LOCK CMPXCHG16B pour seize, quiescence obligatoire — D253) et §8.6 (la garantie R10 bornée
à son ancre ; intégrité/authenticité/fraîcheur ; la restauration cohérente binaire+état
invisible aux ancres locales — D254) ; le manuscrit v0.24.0 et le ratio 63,39/19,66
corrigé de 3,23 à 3,22 à la source (D255) ; le Livre v1.8 (plage D75–D137 alignée, les
trois propriétés de fraîcheur) ; les preuves et la présentation régénérées.

CE QUI DEMEURE EN ATTENTE, NOMMÉ : mesures au métal nu (bascule concurrente, ≥ 2 machines),
sentinelle Windows SACL/4663, IMA/Authenticode configurés, outils Tamarin/ProVerif/Maude
(absents du bac), linter d'édition v2 non porté à cette génération (la porte v0.24.0
couvre versions, empreintes, ratio et provenance).

AUCUN SECRET : ni couche I signée, ni carte C, ni clé, ni phrase de contrôle.
