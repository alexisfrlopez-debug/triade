TRIADE — LE COMPLET DE L'ÉDITION v0.24.0 (la vague 17, 24 novembre 2026)
========================================================================

L'archive complète du dépôt à l'édition v0.24.0 : les sources des cinq pièces
(edition-v0230/, scripts/spec_v158/, scripts/livre_v18/), le pack des cinq pièces
(pack-v240/), les ateliers de la vague 17 (ateliers-vague17/), le paquet de
réplication public (replication-v17/), les scripts de la vague (scripts/vague17 et
vague17/), les instructions exécutées (instructions_vague17_20261124/), le worklog
à l'Entrée 398, REPRISE_PROJET.md et OU-TROUVER à l'état du 24/11, le journal des
décisions (docs/DECISIONS.md, D252–D255) et le rapport de release.

CE QUE PORTE L'ÉDITION : spécification §7.1.1 (atomicité bornée à huit octets
naturels, LOCK CMPXCHG16B pour seize, quiescence obligatoire — D253) et §8.6 (R10
borné à son ancre ; intégrité/authenticité/fraîcheur ; le rollback cohérent
binaire+état invisible aux ancres locales — D254) ; manuscrit v0.24.0 et le ratio
63,39/19,66 corrigé de 3,23 à 3,22 à la source (D255) ; Livre v1.8 (plage D75–D137
alignée) ; preuves et présentation régénérées.

DOIS : protocole v0.24.0 = 10.5281/zenodo.24494615 (concept 24367343) ; corpus v2.1
= 10.5281/zenodo.24479882 (inchangé, non minté) ; pack d'entraînement TRIADE-TRAIN
v1.0.0 = 10.5281/zenodo.24495492.

CE QUI DEMEURE, NOMMÉ : linter d'édition v2 non porté à cette génération ; mesures
au métal nu ; sentinelle Windows SACL/4663 ; IMA/Authenticode ; Tamarin/ProVerif
absents du bac ; la confirmation de la corbeille des anciennes archives au /livrables.

AUCUN SECRET : ni couche I signée, ni carte C, ni clé, ni phrase de contrôle.
