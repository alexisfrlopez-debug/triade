TRIADE — ÉDITION ACADÉMIQUE v0.19.4 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.19.4.pdf    — le manuscrit : LE COÛT DE LA BOUCLE
     SOUS R11 (l'instruction cq01qv1za, la vague 7 quatrième — le plan
     pré-enregistré sha256 cb5d1943… gelé AVANT toute mesure) : LE POINTEUR
     SEUL adopté au localiser (OPT-04 : −35,7 % au total, −93,3 % à la
     réponse, zéro divergence 18/18, l'expansion client à quatre refus
     nommés), LA PILE MÉMO V2 + DOUBLE MOTEUR (la clé fichier + config
     émulateur + graine, le compteur chaîné au cœur signé, l'audit 1 run
     sur 10 vécu — l'identité champ à champ 0 écart ; QEMU-user au volume,
     Unicorn à l'échantillon consigné : DIVERGENCE 0 sur 2 041 opérations),
     LE RATIO 17,9× → 3,0× : H5 DEVIENT TENUE (l'énoncé explicite de
     l'instruction du maître — la falsification D204 demeurant consignée
     comme mesurée et datée), la réconciliation D214 nommée sur pièces (la
     variance inter-bac) ; le dépôt GitHub PUBLIC (D220) et le DOI vivant
     portés au statut exact ;
  3. empreintes_livrables.txt        — les sha256 de chaque pièce du dépôt,
     la pièce scellée loupe.exe 0.1.1 et le scellé proxy.exe 1.0.0 compris
     (le registre fait foi) ;
  4. rapport_verification_v0.19.4.txt — la vérification V1--V10 sur pièces
     (le linter v194 16/16 re-roulé, les empreintes du pack 5/5 recoupées,
     les tableaux GÉNÉRÉS des données brutes et confrontés aux consignés,
     la falsification prouvée, les écarts nommés) ;
  5. tableaux_donnees_v0.19.4.csv    — les données : le round-trip
     instrumenté RQ2, les tables de campagne D204/D210 (portées de la
     v0.19.0), le carnet M3 au geste, LA CAMPAGNE OPT-04 (les 36 appels
     réels du journal des tokens, les distributions natives) et LES MESURES
     M4 de la pile adoptée (les 17 runs aux preuves, les distributions par
     configuration) — chaque valeur GÉNÉRÉE des registres bruts, jamais
     tapée.

Cette version v0.19.4 succède à la v0.19.0 du même concept DOI : elle porte
l'édition courante à la date du 19/11/2026 (la vague 7 : le kit de séquestre
D219, le passage public D220, l'écart CF3 fermé D221, le coût de la boucle
D222). AUCUNE valeur mesurée des éditions scellées antérieures n'est
modifiée — la v0.19.4 est additive.

Licence : Business Source License 1.1 avec Additional Use Grant
académique (peer review, artifact evaluation, réplication scientifique,
recherche non commerciale — la décision D209 ; Change Date 2030-10-28,
conversion GPLv3).
