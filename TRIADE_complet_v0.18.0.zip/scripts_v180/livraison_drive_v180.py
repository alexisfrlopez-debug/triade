#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""livraison_drive_v180.py — LA LIVRAISON DE LA VAGUE 5 AU COFFRE DRIVE :
le manuscrit v0.18.0, les DEUX archives, le rapport de vérification, les
empreintes, le rapport d'exécution des instructions — puis L'ARCHIVAGE des
DIX instructions /instructions → /ARCHIVE/instructions_20261116/ (après
exécution), 10/10 md5 recoupés, avec le rapport d'exécution à côté.
"""
import hashlib
import io
import pathlib
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from google.oauth2 import service_account            # noqa: E402
from googleapiclient.discovery import build          # noqa: E402
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload  # noqa

SA = "/home/z/my-project/upload/physichong-4b3b7222b48c.json"
RACINE = "105MmhMGsVEiDICOv8uM8CVjcBm6pcdYp"
DOSSIER_INSTRUCTIONS = "1uL8fMoXDW9tSsG0L2RoniBYKIjJTLVI6"
ARCHIVE_INSTRUCTIONS = "1qqfk-yMNg3E5s1HVVeEkhmFceeDuPtNb"

creds = service_account.Credentials.from_service_account_file(
    SA, scopes=["https://www.googleapis.com/auth/drive"])
drive = build("drive", "v3", credentials=creds, cache_discovery=False)


def md5(chemin: pathlib.Path) -> str:
    return hashlib.md5(chemin.read_bytes()).hexdigest()


def deposer(chemin: pathlib.Path, parent: str, etiquette: str = "") -> str:
    meta = {"name": chemin.name, "parents": [parent]}
    r = drive.files().create(
        body=meta, media_body=MediaFileUpload(str(chemin), resumable=True)
    ).execute()
    print(f"  [déposé] {chemin.name} → {etiquette or parent[:12]}… "
          f"(id={r['id'][:14]}…)")
    return r["id"]


def contenu_md5(file_id: str) -> str:
    buf = io.BytesIO()
    d = MediaIoBaseDownload(buf, drive.files().get_media(fileId=file_id))
    done = False
    while not done:
        _, done = d.next_chunk()
    return hashlib.md5(buf.getvalue()).hexdigest()


# ---------------------------------------------------------------- la livraison
V5 = pathlib.Path("/home/z/my-project/livraison-vague5")
ARCHIVES = V5 / "archives"
ED = V5 / "edition-v180"

print("=== LA LIVRAISON AU COFFRE (racine) ===")
for chemin, etiquette in (
        (ED / "TRIADE_manuscrit_v0.18.0.pdf", "le manuscrit"),
        (ARCHIVES / "TRIADE_soumission_v0.18.0.zip", "l'archive soumission"),
        (ARCHIVES / "TRIADE_complet_v0.18.0.zip", "l'archive complète"),
        (V5 / "rapport-execution-vague5.txt", "le rapport d'exécution")):
    if chemin.exists():
        deposer(chemin, RACINE, etiquette)
    else:
        print(f"  [ABSENT] {chemin}")

# le rapport de vérification et les empreintes (de l'archive soumission)
print("=== LE RAPPORT DE VÉRIFICATION ET LES EMPREINTES (racine) ===")
sous = ARCHIVES / "soumission"
for nom in ("rapport_verification_v0.18.0.txt",
            "empreintes_livrables.txt"):
    p = sous / nom
    if p.exists():
        deposer(p, RACINE, nom)

# ------------------------------------------------------------- l'archivage
print("=== L'ARCHIVAGE DES DIX INSTRUCTIONS (après exécution) ===")
reponse = drive.files().list(
    q=f"'{DOSSIER_INSTRUCTIONS}' in parents and trashed = false",
    pageSize=50, fields="files(id, name, md5Checksum)").execute()
fichiers = reponse.get("files", [])
print(f"  {len(fichiers)} fichiers au /instructions")
recus = {}
for f in fichiers:
    local = pathlib.Path("/home/z/my-project/instructions-recu") / f["name"]
    recus[f["name"]] = (f["id"], f.get("md5Checksum"),
                        md5(local) if local.exists() else None)

deplaces = 0
for nom, (fid, md5_drive, md5_local) in sorted(recus.items()):
    # le recoup : le md5 du Drive == le md5 du fichier rapatrié AVANT
    # l'exécution (la lecture intégrale préalable)
    if md5_local and md5_drive and md5_local != md5_drive:
        print(f"  [ÉCART] {nom} : md5 Drive {md5_drive} != local "
              f"{md5_local} — REFUS de déplacer")
        continue
    drive.files().update(
        fileId=fid, addParents=ARCHIVE_INSTRUCTIONS,
        removeParents=DOSSIER_INSTRUCTIONS).execute()
    apres = contenu_md5(fid)
    ok = apres == md5_drive
    deplaces += ok
    print(f"  [archivé] {nom} — md5 {'RECROUPÉ' if ok else 'CHANGÉ (!)'} "
          f"{apres}")
print(f"  {deplaces}/{len(recus)} instructions archivées, md5 recoupés")

# le rapport d'exécution aux côtés des instructions archivées
rapport = V5 / "rapport-execution-vague5.txt"
if rapport.exists():
    deposer(rapport, ARCHIVE_INSTRUCTIONS,
            "ARCHIVE/instructions_20261116 (le rapport d'exécution)")
