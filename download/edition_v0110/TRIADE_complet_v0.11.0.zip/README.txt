TRIADE — ÉDITION ACADÉMIQUE v0.11.0 — ARCHIVE COMPLÈTE
======================================================

L'intégralité des preuves renforcées : le manuscrit étendu ET ses
sources, la spécification v0.11.0 et sa chaîne LaTeX, LES SIX
INSTRUMENTS avec leurs scripts ET leurs sorties brutes (CSV/JSON/
rapports), la référence C à contrat équivalent, la spécification CSPRNG
en brouillon (tls13-29 — la cérémonie d'ère attend le geste du
développeur), le corpus de vecteurs RFC 8446, le constat du rejeu
intégral des harnais, les extraits de journal et les empreintes.

Arborescence :
  README.txt                      ce guide
  manuscrit/                      le PDF + main.tex + refs.bib + données
  specification/                  le PDF v0.11.0 + la chaîne spec_v110
  instruments/                    LES SIX scripts + sorties brutes
  instruments/reference_C/        bench.c (la référence à contrat équivalent)
  spec-csprng/                    tls13-29 (le brouillon, D186)
  corpus/                         rfc8446.py (les vecteurs, D186)
  journal/                        les extraits + le rejeu intégral
  journal/decisions_D185-D186.md  les décisions des preuves
  journal/entree_224.md           l'entrée du journal
  VERIFICATION_v0.11.0.txt        le constat de vérification
  empreintes_complet.txt          sha-256 de tout ce qui précède

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
