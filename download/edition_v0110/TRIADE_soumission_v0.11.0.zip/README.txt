TRIADE — ÉDITION ACADÉMIQUE v0.11.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers, le maximum exigé) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.11.0.pdf    — le manuscrit IMRAD ÉTENDU (la
     section Results § 4.5 « Strengthened evidence » : les six
     instruments de la v0.11.0 avec leurs tables générées) ;
  3. tableaux_donnees_v0.11.0.csv    — TOUS les tableaux : les données
     v0.10.0 (jalons, budgets, oracles, runs, empreintes) ET les preuves
     v0.11.0 (mutation, temps constant, indépendance, sûreté mémoire,
     benchmarks) — générés, jamais tapés ;
  4. empreintes_soumission.txt       — les empreintes sha-256 ;
  5. VERIFICATION_v0.11.0.txt        — le constat : le rejeu INTÉGRAL des
     harnais (159 Loupe + 284 tls13 + 131 sys + garde du sceau 14/14),
     les artefacts scellés byte pour byte, l'audit de gouvernance.

Les six instruments (détails dans le manuscrit § 4.5) :
  - mutation testing   : 832 mutants, 694 tués (83,4 %) — les familles
    crypto à 100 %, les 138 survivants d'orchestration NOMMÉS ;
  - fuzzage guidé      : loupe-01 60,5 % de couverture, zéro crash,
    zéro canari violé ; http-10 : 358 instructions, zéro faute ;
  - sûreté mémoire     : 2 098 accès classés, ZÉRO hors-cadre,
    463 non résolus nommés (analyse bornée, limites consignées) ;
  - temps constant     : dudect d'émulation — toutes les familles
    crypto CONSTANTES (traces indépendantes du secret) ; le temps réel
    N'EST PAS MESURÉ (la limite explicite) ;
  - benchmarks         : sha256 4 524 ins/op (blocs à la main) contre
    69 132 (gcc -O2) au MÊME émulateur — facteur 15,3 ; md5/aes écartés
    par l'auto-vérification (le C de référence fautif refusé) ;
  - indépendance       : zéro divergence par voies distinctes.

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
