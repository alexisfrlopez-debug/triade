package com.triade.kitandroid;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * TRIADE Kit Android v1 — l'activité unique.
 *
 * Le geste en un clic : l'ouverture de l'application démarre le relais Python
 * (CPython embarqué Chaquopy), qui vérifie les empreintes du kit scellé
 * (fail-closed), sert l'interface sur 127.0.0.1:8420, puis la page lance le
 * test toute seule. Le kit constat-arm.py s'exécute EN PROCESSUS, jamais
 * modifié — ses preuves naissent dans preuves-constat-arm/.
 *
 * Aucun jeton n'est embarqué : l'envoi au coffre passe par le partage Android
 * (l'app Drive), exactement la frontière honnête du GUI v1.
 */
public class MainActivity extends Activity implements Partage {

    private static final String TAG = "TRIADE";
    private static final String SERVEUR = "http://127.0.0.1:8420/";
    private static final String[] KIT = {
            "constat-arm.py", "lancer-kit-constat-arm.sh", "LISEZMOI-constat-arm.txt"
    };

    private WebView vue;
    private int tentatives = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        vue = new WebView(this);
        vue.getSettings().setJavaScriptEnabled(true);
        vue.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Rien ne quitte la boucle locale : aucune navigation externe.
                return !r.getUrl().toString().startsWith("http://127.0.0.1:8420");
            }

            @Override
            public void onReceivedError(WebView v, int code, String desc, String url) {
                if (url != null && url.startsWith("http://127.0.0.1") && tentatives < 20) {
                    tentatives++;
                    vue.postDelayed(() -> vue.loadUrl(SERVEUR), 400);
                }
            }
        });
        setContentView(vue);
        vue.loadDataWithBaseURL(null, accueil(),
                "text/html; charset=utf-8", null, null);
        try {
            extraireKit();
        } catch (Exception e) {
            vue.loadDataWithBaseURL(null, echap(
                    "L'EXTRACTION DU KIT A REFUSÉ :\n\n" + e),
                    "text/plain; charset=utf-8", null, null);
            return;
        }
        new Thread(this::partirPython, "relais-python").start();
    }

    /** Les 3 fichiers du kit scellé, des assets vers filesDir/kit-constat-arm/. */
    private void extraireKit() throws Exception {
        File dest = new File(getFilesDir(), "kit-constat-arm");
        if (!dest.exists() && !dest.mkdirs()) {
            throw new Exception("mkdir impossible : " + dest);
        }
        for (String n : KIT) {
            File cible = new File(dest, n);
            try (InputStream entree = getAssets().open("kits/kit-constat-arm/" + n);
                 OutputStream sortie = new FileOutputStream(cible)) {
                byte[] tampon = new byte[8192];
                int lus;
                while ((lus = entree.read(tampon)) > 0) {
                    sortie.write(tampon, 0, lus);
                }
            }
        }
        Log.i(TAG, "kit extrait : 3 fichiers vers " + dest);
    }

    private void partirPython() {
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(getApplicationContext()));
            }
            PyObject module = Python.getInstance().getModule("triade_apk");
            PyObject reponse = module.callAttr(
                    "demarrer", getFilesDir().getAbsolutePath(), this);
            final String rapport = reponse.toString();
            Log.i(TAG, "demarrer → " + rapport);
            runOnUiThread(() -> {
                tentatives = 0;
                vue.loadUrl(SERVEUR);
            });
        } catch (final Throwable t) {
            Log.e(TAG, "relais python", t);
            runOnUiThread(() -> vue.loadDataWithBaseURL(null, echap(
                    "LE RELAIS PYTHON A REFUSÉ DE PARTIR :\n\n" + t),
                    "text/plain; charset=utf-8", null, null));
        }
    }

    // ------------------ le pont Partage, appelé depuis Python ------------------

    @Override
    public void partager(final String chemin) {
        runOnUiThread(() -> {
            File fichier = new File(chemin);
            if (!fichier.exists()) {
                Log.e(TAG, "partager : fichier absent " + chemin);
                return;
            }
            Uri uri = FileProvider.getUriForFile(MainActivity.this,
                    getPackageName() + ".filepartage", fichier);
            Intent envoi = new Intent(Intent.ACTION_SEND);
            envoi.setType("application/zip");
            envoi.putExtra(Intent.EXTRA_STREAM, uri);
            envoi.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(envoi,
                    "Envoyer le zip vers… (Drive : dossier « Triade » → test)"));
        });
    }

    @Override
    public void partagerTexte(final String texte) {
        runOnUiThread(() -> {
            Intent envoi = new Intent(Intent.ACTION_SEND);
            envoi.setType("text/plain; charset=utf-8");
            envoi.putExtra(Intent.EXTRA_TEXT, texte);
            startActivity(Intent.createChooser(envoi, "Partager le verdict…"));
        });
    }

    // ------------------ petites pages locales ------------------

    private String accueil() {
        return "<html><body style='background:#0b1220;color:#d5e2f3;"
                + "font-family:sans-serif;padding:24px'>"
                + "<h2>TRIADE Kit Android</h2>"
                + "<p>Le relais Python part… l'interface du constat arrive "
                + "à l'instant sur cette page (127.0.0.1:8420).</p>"
                + "<p style='color:#7c93ad'>Le kit scellé vérifié par empreintes, "
                + "le test lancé à l'ouverture — un seul clic.</p>"
                + "</body></html>";
    }

    private String echap(String s) {
        return "<pre style='white-space:pre-wrap'>"
                + s.replace("&", "&amp;").replace("<", "&lt;") + "</pre>";
    }
}
