package com.triade.kitandroid;

/** Le pont appelé depuis Python (triade_apk.py) pour les partages Android. */
public interface Partage {
    /** Partager le zip des preuves (application/zip) — vers l'app Drive. */
    void partager(String chemin);
    /** Partager le verdict auto-portant en texte. */
    void partagerTexte(String texte);
}
