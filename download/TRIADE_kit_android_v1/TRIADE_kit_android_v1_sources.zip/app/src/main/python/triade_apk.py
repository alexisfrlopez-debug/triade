#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""triade_apk.py — LE RELAIS PYTHON DE L'APK « TRIADE KIT ANDROID » v1.

La commande du développeur (13/11/2026) : « pour le kit android, fais un apk
autonome que je puisse faire le test en 1 clic ».

Ce module vit DANS l'APK (Chaquopy, CPython embarqué). L'APK embarque le kit
scellé kit-constat-arm/ — les 3 fichiers du paquet CORRECTIF2, octet pour
octet, dont les empreintes sont revérifiées à chaque démarrage (fail-closed :
REFUS nommé, jamais un run sur un kit divergent). Le test = constat-arm.py
exécuté EN PROCESSUS, JAMAIS modifié : ses preuves naissent dans
preuves-constat-arm/ exactement comme au Termux (D99 : les runs ne se
mélangent jamais — un run achevé est archivé horodaté avant le suivant).

L'interface vit sur 127.0.0.1:8420 (aucun autre réseau) ; la page lance le
test à l'ouverture — le 1 clic. L'envoi au coffre passe par le partage
Android (l'app Drive) : AUCUN jeton embarqué, la même frontière honnête que
le GUI v1 (le relais du labo relèvera les preuves au coffre /test).

Éprouvable au labo : ce module est écrit stdlib pure et se teste headless
sur n'importe quel hôte (scripts/tester_triade_apk.py) ; sur x86-64 le
constat dit honnêtement « ceci n'est pas un téléphone ARM » et rend VERT.
"""
import datetime
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import threading
import traceback
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

VERSION = "1.0"
PORT = 8420
KIT_DIRNAME = "kit-constat-arm"
RECEPTEUR = "preuves-constat-arm"
ARCHIVES = "preuves-archives"
LOGS = "TRIADE_logs"

# Les empreintes du kit scellé — celles du paquet livré au coffre
# (TRIADE_kits_terrain_v0150_CORRECTIF2-kit-dudect.zip, sha256 0e930b80…,
# source de vérité). Toute divergence = REFUS nommé avant le run.
FICHIERS_KIT = {
    "constat-arm.py":
        "cfaf4473cd5c40d6ef6159dc85dc23ce92e48a5983baa0f3875bef1d8189fb6e",
    "lancer-kit-constat-arm.sh":
        "830793014fa2b56eb02296a8672cfafe1ee46944042bbc51ba018f060aac1081",
    "LISEZMOI-constat-arm.txt":
        "7509e593b1db352dee12be33e3420d4620809a2e57121c23f05e29d97b3f8817",
}

_verrou = threading.Lock()
_racine = None          # Path — filesDir de l'APK (ou du harnais de labo)
_hook = None            # le pont Java Partage (None au labo)
_etat = {
    "phase": "DEMARRAGE",      # PRET | REFUS | RUN | VERT | ECHEC
    "integrite": "",
    "rc": None,
    "verdict": "",
    "journal": [],
    "log": "",
    "zip": None,
    "erreur": "",
    "run_ts": "",
    "archives": 0,
}
_log_fh = None


def _maj(**champs):
    with _verrou:
        _etat.update(champs)
        if "journal" in champs:
            pass  # liste remplacée telle quelle


def _lignes_etat():
    with _verrou:
        return dict(_etat)


# ---------------------------------------------------------------- le journal
def _journal_ecrit(texte, prefixe=""):
    """Une écriture capturée : state (console live) + fichier de log."""
    for ligne in texte.splitlines():
        if not ligne.strip("\r"):
            continue
        entree = (prefixe + ligne.strip("\r\n") if prefixe else ligne)
        with _verrou:
            _etat["journal"].append(entree)
            if len(_etat["journal"]) > 500:
                del _etat["journal"][:250]
    if _log_fh is not None:
        try:
            _log_fh.write(texte if texte.endswith("\n") else texte + "\n")
            _log_fh.flush()
        except Exception:
            pass


class _Tee:
    """Capture stdout/stderr du constat : la console live, sans rien perdre."""

    def __init__(self, original, prefixe=""):
        self._original = original
        self._prefixe = prefixe

    def write(self, s):
        try:
            self._original.write(s)
        except Exception:
            pass
        if s:
            _journal_ecrit(s, self._prefixe)
        return len(s)

    def flush(self):
        try:
            self._original.flush()
        except Exception:
            pass

    def __getattr__(self, nom):          # encoding, isatty, etc.
        return getattr(self._original, nom)


# ---------------------------------------------------------------- le kit
def _sha256(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 16), b""):
            h.update(bloc)
    return h.hexdigest()


def _verifier_kit(kit):
    """Fail-closed : chaque fichier doit être l'octet pour octet du coffre."""
    ecarts = []
    for nom, attendu in sorted(FICHIERS_KIT.items()):
        p = kit / nom
        if not p.exists():
            ecarts.append(f"{nom} ABSENT")
            continue
        rendu = _sha256(p)
        if rendu != attendu:
            ecarts.append(f"{nom} sha256 {rendu[:12]}… ≠ coffre {attendu[:12]}…")
    if ecarts:
        return False, "REFUS — kit divergent : " + " ; ".join(ecarts)
    return True, ("kit-constat-arm intègre : 3/3 sha256 EXACTS "
                  "(octet pour octet le paquet CORRECTIF2 du coffre)")


def _charger_constat(kit):
    """constat-arm.py chargé comme module — aucune modification, aucun fork."""
    spec = importlib.util.spec_from_file_location(
        "constat_arm_vivant", str(kit / "constat-arm.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------- le run
def _entete_env():
    lignes = []
    lignes.append("[env] relais triade_apk.py v" + VERSION
                  + " — TRIADE Kit Android (CPython embarqué, en processus)")
    try:
        api = sys.getandroidapilevel()
        lignes.append(f"[env] Android API {api} — Chaquopy (CPython embarqué)")
    except AttributeError:
        lignes.append("[env] hors Android — épreuve headless du labo "
                      "(le même code, le même constat)")
    lignes.append("[env] python " + sys.version.split()[0]
                  + " · " + str(_racine))
    try:
        lignes.append("[env] uname " + " ".join(os.uname()))
    except Exception:
        pass
    lignes.append("[env] " + datetime.datetime.now(
        datetime.timezone.utc).isoformat(timespec="seconds") + " UTC")
    lignes.append("[env] le kit CONSTATE — il ne mesure rien (D206) ; "
                  "les runs ne se mélangent jamais (D99)")
    return lignes


def _archiver_preuves():
    """D99 : le run achevé part aux archives horodatées avant le suivant."""
    recep = _racine / RECEPTEUR
    if not recep.exists() or not any(recep.iterdir()):
        return None
    ts = datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y%m%dT%H%M%SZ")
    dest = _racine / ARCHIVES / ts
    if dest.exists():
        return dest.name
    shutil.move(str(recep), str(dest))
    with _verrou:
        _etat["archives"] += 1
    return dest.name


def _travail_run(refaire=False):
    global _log_fh
    vieux_stdout, vieux_stderr = sys.stdout, sys.stderr
    try:
        kit = _racine / KIT_DIRNAME
        ts = datetime.datetime.now(datetime.timezone.utc).strftime(
            "%Y%m%dT%H%M%SZ")
        _archiver_preuves()
        log_dir = _racine / LOGS
        log_dir.mkdir(exist_ok=True)
        log_chemin = log_dir / f"kit_android_{ts}.log"
        _log_fh = open(log_chemin, "w", encoding="utf-8")
        _maj(phase="RUN", rc=None, verdict="", journal=[], erreur="",
             log=str(log_chemin), zip=None, run_ts=ts)
        for ligne in _entete_env():
            _journal_ecrit(ligne + "\n")
        _journal_ecrit("[run] === constat-arm.py — exécution EN PROCESSUS "
                       "(le kit scellé, jamais modifié) ===\n")

        sys.stdout = _Tee(vieux_stdout)
        sys.stderr = _Tee(vieux_stderr, "[stderr] ")
        module = _charger_constat(kit)
        rc = module.main()
        sys.stdout, sys.stderr = vieux_stdout, vieux_stderr

        verdict = ""
        chemin_verdict = _racine / RECEPTEUR / "constat-arm-verdict.txt"
        if chemin_verdict.exists():
            verdict = chemin_verdict.read_text(encoding="utf-8")
        phase = "VERT" if rc == 0 else "ECHEC"
        _journal_ecrit(f"[run] terminé — code {rc} "
                       f"({'VERT' if rc == 0 else 'ÉCHEC NOMMÉ'})\n")
        _journal_ecrit("[run] preuves-constat-arm/ : journal + verdict "
                       "auto-portant\n")
        _maj(phase=phase, rc=rc, verdict=verdict)
    except SystemExit as e:
        sys.stdout, sys.stderr = vieux_stdout, vieux_stderr
        rc = e.code if isinstance(e.code, int) else 3
        _journal_ecrit(f"[run] SystemExit {rc}\n")
        _maj(phase="ECHEC", rc=rc,
             verdict=(_racine / RECEPTEUR / "constat-arm-verdict.txt").
             read_text(encoding="utf-8")
             if (_racine / RECEPTEUR / "constat-arm-verdict.txt").exists()
             else "")
    except Exception as e:
        sys.stdout, sys.stderr = vieux_stdout, vieux_stderr
        tb = traceback.format_exc()
        if _log_fh is not None:
            try:
                _log_fh.write("\n[échec relais] " + tb)
            except Exception:
                pass
        _journal_ecrit("[relais] ÉCHEC : " + repr(e) + "\n")
        _maj(phase="ECHEC", rc=None, erreur=repr(e))
    finally:
        if _log_fh is not None:
            try:
                _log_fh.close()
            except Exception:
                pass
            _log_fh = None


# ---------------------------------------------------------------- le zip
def _texte_depot(run_ts):
    kit = _racine / KIT_DIRNAME
    empreintes = "\n".join(
        f"  {nom} : {attendu}" for nom, attendu in sorted(FICHIERS_KIT.items()))
    return f"""LE DÉPÔT DES PREUVES — TRIADE Kit Android v{VERSION}
Run : {run_ts} (UTC)

OÙ DÉPOSER : le dossier Drive « Triade » → sous-dossier « test »
(ce zip s'y dépose par le bouton ENVOYER LE ZIP → Drive, ou par l'app
Drive — même geste que le terrain).

CE QUE CONTIENT CE ZIP :
  preuves-constat-arm/constat-arm-journal.log   le run entier, ligne par ligne
  preuves-constat-arm/constat-arm-verdict.txt   le verdict auto-portant
  TRIADE_logs/kit_android_{run_ts}.log          le journal du relais (environnement + run)

LE GESTE QUI RESTE À VOTRE MAIN (le LISEZMOI du kit) : datez et signez le
verdict de votre main, puis renvoyez le dossier ENTIER — le labo recoupe et
consigne : JAMAIS avant le run, jamais sans pièces (D189).

LE KIT EMBARQUÉ (octet pour octet le paquet CORRECTIF2 du coffre) :
{empreintes}

Le kit CONSTATE — il ne mesure rien ; aucun protocole pré-enregistré
n'existe pour ce silicium, aucun chiffre n'est fabriqué (D206).
Aucun jeton n'est embarqué dans l'APK : l'envoi passe par le partage Android.
"""


def _construire_zip(run_ts):
    chemin = _racine / f"TRIADE_kit_android_{run_ts}.zip"
    morceaux = [
        f"{RECEPTEUR}/constat-arm-journal.log",
        f"{RECEPTEUR}/constat-arm-verdict.txt",
        f"{LOGS}/kit_android_{run_ts}.log",
    ]
    with zipfile.ZipFile(chemin, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in morceaux:
            p = _racine / rel
            if p.exists():
                z.write(p, rel)
        z.writestr("DEPOT.txt", _texte_depot(run_ts))
    return chemin


# ---------------------------------------------------------------- le serveur
class _Handler(BaseHTTPRequestHandler):

    def _envoyer(self, code, corps, type_mime):
        donnees = corps if isinstance(corps, bytes) else corps.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", type_mime)
        self.send_header("Content-Length", str(len(donnees)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(donnees)

    def _json(self, code, obj):
        self._envoyer(code, json.dumps(obj, ensure_ascii=False),
                      "application/json; charset=utf-8")

    def log_message(self, *args):
        pass

    def do_GET(self):
        chemin = urlparse(self.path).path
        if chemin in ("/", "/index.html"):
            self._envoyer(200, PAGE(), "text/html; charset=utf-8")
        elif chemin == "/api/state":
            etat = _lignes_etat()
            etat["journal"] = list(etat["journal"][-200:])
            self._json(200, etat)
        else:
            self._json(404, {"erreur": "inconnu"})

    def do_POST(self):
        analyse = urlparse(self.path)
        chemin, requete = analyse.path, parse_qs(analyse.query)
        longueur = int(self.headers.get("Content-Length") or 0)
        if longueur:
            self.rfile.read(longueur)
        if chemin == "/api/run":
            refaire = requete.get("refaire", ["0"])[0] == "1"
            with _verrou:                     # lecture brève, JAMAIS de _maj
                phase = _etat["phase"]         # sous le verrou (Lock non
                integrite = _etat["integrite"]  # réentrant — le piège vécu)
            if phase == "RUN":
                self._json(409, {"erreur": "le test court déjà"})
                return
            if phase == "REFUS":
                self._json(403, {"erreur": integrite})
                return
            if phase in ("VERT", "ECHEC") and not refaire:
                self._json(409, {"erreur":
                                 "test déjà terminé — REFAIRE LE TEST "
                                 "pour relancer (l'ancien run part aux "
                                 "archives horodatées)"})
                return
            _maj(phase="RUN", rc=None, verdict="", journal=[],
                 erreur="", zip=None)
            threading.Thread(target=_travail_run,
                             kwargs={"refaire": refaire},
                             name="run-constat", daemon=True).start()
            self._json(202, {"ok": True})
        elif chemin == "/api/share":
            with _verrou:
                phase, run_ts = _etat["phase"], _etat["run_ts"]
            if phase not in ("VERT", "ECHEC") or not run_ts:
                self._json(409, {"erreur": "aucun run achevé à partager"})
                return
            if requete.get("quoi", ["zip"])[0] == "verdict":
                texte = _etat.get("verdict") or ""
                if _hook is not None:
                    _hook.partagerTexte(texte)
                    self._json(200, {"mode": "intent-texte"})
                else:
                    self._json(200, {"mode": "manuel-texte", "verdict": texte})
                return
            with _verrou:
                deja = _etat.get("zip")
            chemin_zip = Path(deja) if deja and deja.endswith(".zip") and \
                Path(deja).exists() else None
            if chemin_zip is None:
                chemin_zip = _construire_zip(run_ts)
                _maj(zip=str(chemin_zip))
            if _hook is not None:
                _hook.partager(str(chemin_zip))
                self._json(200, {"mode": "intent", "zip": str(chemin_zip)})
            else:
                self._json(200, {"mode": "manuel", "zip": str(chemin_zip),
                                 "note": "partage indisponible hors Android — "
                                         "posez ce zip dans le Drive "
                                         "(Triade → test)"})
        else:
            self._json(404, {"erreur": "inconnu"})


# ---------------------------------------------------------------- la page
def PAGE():
    return _PAGE


_PAGE = """<!doctype html>
<html lang="fr"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TRIADE Kit Android</title>
<style>
 :root { color-scheme: dark; }
 * { box-sizing: border-box; }
 body { margin:0; background:#0b1220; color:#d5e2f3;
        font-family: system-ui, sans-serif; padding:14px; }
 h1 { font-size:1.15rem; margin:0 0 2px; }
 .sous { color:#7c93ad; font-size:.85rem; margin-bottom:12px; }
 .carte { background:#111a2c; border:1px solid #1e2c46; border-radius:10px;
          padding:12px; margin-bottom:12px; }
 .badge { display:inline-block; padding:3px 12px; border-radius:999px;
          font-weight:700; font-size:.9rem; }
 .badge.bleu  { background:#1d4ed833; color:#93c5fd; border:1px solid #1d4ed8; }
 .badge.ambre { background:#f59e0b33; color:#fbbf24; border:1px solid #f59e0b; }
 .badge.vert  { background:#10b981; color:#06281e; }
 .badge.rouge { background:#ef4444; color:#2b0a0a; }
 #integrite { color:#94a3b8; font-size:.82rem; margin-top:8px;
              white-space:pre-wrap; }
 #rc { color:#fbbf24; font-size:.85rem; margin-top:4px; }
 #auto-note { display:none; color:#93c5fd; font-size:.82rem; margin-top:8px; }
 .boutons { display:flex; flex-wrap:wrap; gap:8px; }
 button { flex:1 1 46%; min-width:150px; padding:13px 8px; border:0;
          border-radius:10px; font-size:.95rem; font-weight:700; }
 button:disabled { opacity:.35; }
 .b-vert  { background:#10b981; color:#06281e; }
 .b-bleu  { background:#2563eb; color:#e7f0ff; }
 .b-ambre { background:#f59e0b; color:#3a2503; }
 .b-gris  { background:#334766; color:#e7eefb; }
 pre { white-space:pre-wrap; word-break:break-word; margin:0;
       font-family:ui-monospace, Menlo, Consolas, monospace;
       font-size:.78rem; line-height:1.45; }
 .titre-pre { color:#7c93ad; font-size:.8rem; margin:0 0 6px;
              text-transform:uppercase; letter-spacing:.06em; }
 #journal { max-height:38vh; overflow-y:auto; }
 #verdict { max-height:32vh; overflow-y:auto; }
 .pied { color:#7c93ad; font-size:.75rem; line-height:1.6; }
 .pied b { color:#a9bdd8; }
</style></head>
<body>
 <h1>TRIADE Kit Android <span style="color:#7c93ad">v1.0</span></h1>
 <div class="sous">le troisième silicium — le constat en 1 clic (kit scellé
 embarqué, exécuté en processus)</div>

 <div class="carte">
   <span id="badge" class="badge bleu">…</span>
   <div id="integrite"></div>
   <div id="rc"></div>
   <div id="auto-note">test lancé automatiquement à l'ouverture —
   le 1 clic du développeur.</div>
   <div id="note-run" style="color:#fbbf24; font-size:.82rem; margin-top:6px;
        white-space:pre-wrap"></div>
 </div>

 <div class="carte">
   <div class="boutons">
     <button id="b-lancer"  class="b-vert"  disabled>LANCER LE TEST</button>
     <button id="b-refaire" class="b-bleu"  disabled>REFAIRE LE TEST</button>
     <button id="b-zip"     class="b-ambre" disabled>ENVOYER LE ZIP AU DRIVE</button>
     <button id="b-verdict" class="b-gris"  disabled>PARTAGER LE VERDICT</button>
   </div>
 </div>

 <div class="carte">
   <div class="titre-pre">Verdict auto-portant (constat-arm-verdict.txt)</div>
   <pre id="verdict">(aucun verdict encore — il naît à la fin du run)</pre>
 </div>

 <div class="carte">
   <div class="titre-pre">Journal du run — live</div>
   <pre id="journal">…</pre>
 </div>

 <div class="pied">
   <b>Le kit CONSTATE — il ne mesure rien</b> (D206) : la machine nommée, le
   silicium lu par ses propres canaux, le refus des pièces x86-64 nommé, le
   lecteur FIPS exact.<br>
   <b>Aucun jeton embarqué</b> : ENVOYER LE ZIP ouvre le partage Android —
   choisissez Drive, dossier « Triade » → « test », et enregistrez.
   Le labo relèvera les preuves au coffre.<br>
   Datez et signez le verdict de votre main (le LISEZMOI du kit) — les runs
   ne se mélangent jamais (D99) : REFAIRE archive l'ancien horodaté.
 </div>

<script>
 var autoFait = false;
 function apiPost(u){ return fetch(u, {method:'POST'}); }
 function majBoutons(s){
   var fini = (s.phase==='VERT' || s.phase==='ECHEC');
   document.getElementById('b-lancer').disabled  = s.phase !== 'PRET';
   document.getElementById('b-refaire').disabled = !fini;
   document.getElementById('b-zip').disabled     = !fini;
   document.getElementById('b-verdict').disabled = !fini;
 }
 function majCarte(s){
   var b = document.getElementById('badge');
   b.textContent = s.phase;
   b.className = 'badge ' + (s.phase==='VERT' ? 'vert'
                : (s.phase==='ECHEC' || s.phase==='REFUS') ? 'rouge'
                : s.phase==='RUN' ? 'ambre' : 'bleu');
   document.getElementById('integrite').textContent = s.integrite || '';
   document.getElementById('rc').textContent =
     (s.rc===null || s.rc===undefined) ? '' : ('code de sortie : ' + s.rc);
 }
 function rafraichir(){
   fetch('/api/state').then(function(r){ return r.json(); }).then(function(s){
     majCarte(s); majBoutons(s);
     document.getElementById('verdict').textContent =
       s.verdict || '(aucun verdict encore — il naît à la fin du run)';
     var j = document.getElementById('journal');
     j.textContent = (s.journal || []).slice(-180).join('\\n') || '…';
     j.scrollTop = j.scrollHeight;
     if (s.phase==='PRET' && !autoFait) {
       autoFait = true;
       document.getElementById('auto-note').style.display='block';
       apiPost('/api/run');
     } else if (s.phase!=='PRET') {
       document.getElementById('auto-note').style.display='none';
     }
   }).catch(function(){});
 }
 document.getElementById('b-lancer').onclick  = function(){ apiPost('/api/run'); };
 document.getElementById('b-refaire').onclick = function(){ apiPost('/api/run?refaire=1'); };
 document.getElementById('b-zip').onclick = function(){
   apiPost('/api/share').then(function(r){ return r.json(); }).then(function(j){
     document.getElementById('note-run').textContent =
       (j.mode==='intent')
         ? 'partage Android ouvert — choisissez Drive (Triade → test) et enregistrez le zip.'
         : ('posez ce zip dans le Drive (Triade → test) : ' + (j.zip || ''));
   });
 };
 document.getElementById('b-verdict').onclick = function(){
   apiPost('/api/share?quoi=verdict');
 };
 setInterval(rafraichir, 900);
 rafraichir();
</script>
</body></html>
"""


# ---------------------------------------------------------------- démarrage
def demarrer(racine, hook=None):
    """Appelé depuis Java (ou du harnais de labo). Retourne un rapport court."""
    global _racine, _hook
    _racine = Path(racine)
    _hook = hook
    os.chdir(_racine)

    ok, message = _verifier_kit(_racine / KIT_DIRNAME)
    _maj(integrite=message, phase="PRET" if ok else "REFUS")

    serveur = ThreadingHTTPServer(("127.0.0.1", PORT), _Handler)
    threading.Thread(target=serveur.serve_forever,
                     name="serveur-web", daemon=True).start()
    for _ in range(40):                       # la boucle locale, prête ?
        try:
            socket.create_connection(("127.0.0.1", PORT), timeout=0.4).close()
            break
        except OSError:
            time_court()
    return ("ok:3/3 — relais v" + VERSION + " sur 127.0.0.1:" + str(PORT)
            + " ; " + message) if ok else ("refus — " + message)


def time_court():
    import time
    time.sleep(0.05)


if __name__ == "__main__":     # jamais dans l'APK ; commodité de labo
    import tempfile
    print(demarrer(tempfile.mkdtemp(prefix="triade_apk_lab_")))
