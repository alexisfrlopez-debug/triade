#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verifier_paquet.py — LE VÉRIFICATEUR D'INTÉGRITÉ DE L'EXTRACTION (l'édition
MISE À JOUR du paquet multimachines, 12/11/2026, troisième geste).

Le manifeste gravé ci-dessous fut calculé au LABORATOIRE sur le montage
même du paquet (chaque pièce telle qu'elle vit dans le zip livré — les .bat
en CRLF, leur forme canonique). Le vérificateur recoupe chaque pièce de
VOTRE extraction : l'extraction incomplète, l'exe retiré par l'antivirus
(l'événement du 12/11 : test_appel.exe refusé par le coffre Drive même,
HTTP 403 « malware or spam » — un faux positif des exe de mesure de
timing), la pièce bougée — TOUT écart est NOMMÉ, jamais maquillé (D189).

L'HONNÊTETÉ DU MANIFESTE : il couvre les 45 pièces du paquet, TOUTES
sauf le vérificateur lui-même — un fichier ne peut pas sceller sa propre
empreinte sans cercle ; l'empreinte du vérificateur et celle du présent
fichier EMPREINTES-PAQUET.txt sont rendues par le sha256 du zip ENTIER,
consigné à l'Entrée 249 du journal de travail et au coffre /test.

Le rapport naît dans verification-paquet.txt. Code de sortie : 0 si
TOUT est vert, 1 s'il y a des écarts (chaque écart est un résultat),
2 si le vérificateur lui-même fautait.
"""

import hashlib
import pathlib
import sys

SORTIE = "verification-paquet.txt"

# LE MANIFESTE GRAVÉ (calculé au laboratoire, 45 pièces — tout sauf ce
# fichier même : voyez l'HONNÊTETÉ ci-dessus).
MANIFESTE =  {
    'A-LIRE-AUTOMATISATION.txt': 'aa70e15683a4838abbfa64e8fba2c32e15738c82e0992c4675915947f47a621a',
    'CE-QUI-RESTE-A-FAIRE.txt': 'fd472e8f4828928ece6394ee87e3bd9e2e9753f0a922ae0f4cd89fea482525be',
    'COMMENCER-ICI.bat': 'aa7b44a9ad128c9487e667f649a076dbb674dc68470f484f02cae75d61483be4',
    'DIAGNOSTIC-MACHINE.bat': '5ea985738d8912280e08a809a780f7e3484853b7a1506f4651986c7022605493',
    'EMPREINTES-PAQUET.txt': '24427b64ec9efce983da3b61349440f19854803d5e5c49b2a805b739e82046e8',
    'LISEZMOI-MULTIMACHINES.txt': 'f1edcb76bafb34349b984d04a6a325edc47476d77eaa81e55574cd76905975a2',
    'VERIFIER-PAQUET.bat': '5597c771ab21c61026ab1131e34de05537a2d531689b8ba44d739c4aa223da91',
    'diagnostic_machine.py': 'b20621579426448ca9467813d2b32d6da97615b20e9a3422299404a8a32194f3',
    'pc-windows/kit-1-shani/LANCER-KIT-1-SHANI.bat': '4c5be578398eb95effabd743311dc010a3ddbba1395e2859835f776e02f5b741',
    'pc-windows/kit-1-shani/LISEZMOI-shani.txt': 'b78caab0792fcfe93f9f12ad004abaec47e62a11630142989c640262c56b62bd',
    'pc-windows/kit-1-shani/cibles/manifeste.json': '93d5a13fcc4d1cb2598b471e291266654d8fec18a9dd3800dba297fbc649db52',
    'pc-windows/kit-1-shani/cibles/proxy-image.bin': '0782d7e20d0bd4a268e6ec7ed0dc1453a0f42d7e72b784c2acc9ed423a885dff',
    'pc-windows/kit-1-shani/moteur-shani.bin': '761ab194d88d527c653111a41324b0bb3e9247b1c56ba8dc9fedeeccbe04bcec',
    'pc-windows/kit-1-shani/moteur-shani.s': 'd930cac0c6b00db0ad31108286e76ced084e417369c81fe68151100709faa1ad',
    'pc-windows/kit-1-shani/scenario-shani.py': 'd9def0b4d714392afcbb8a496ab0dface1b97e4398acf56d68f98c63d79d230a',
    'pc-windows/kit-2-dudect/LANCER-KIT-2-DUDECT.bat': 'e5c3dee06a1d50b6e9bb2e549a5dcbe27adfa33e2669f6509e76fc2a546a67a0',
    'pc-windows/kit-2-dudect/LISEZMOI-dudect.txt': 'a6269ebe310f741bdfa2ccb6cc9c2dcf898eb1fc3679c0e76f40c3ac62feb470',
    'pc-windows/kit-2-dudect/cibles/manifeste-c.txt': '7293cd86359cebba81d590173a49c462f876cf5ce8b639d5c26c2577713ea5d8',
    'pc-windows/kit-2-dudect/cibles/manifeste.json': '93d5a13fcc4d1cb2598b471e291266654d8fec18a9dd3800dba297fbc649db52',
    'pc-windows/kit-2-dudect/cibles/proxy-image.bin': '0782d7e20d0bd4a268e6ec7ed0dc1453a0f42d7e72b784c2acc9ed423a885dff',
    'pc-windows/kit-2-dudect/dudect_v150.c': '8c90ef8232e478a41d38a9edbba21f14f037939d7e8900d643063f5df53f06f3',
    'pc-windows/kit-2-dudect/dudect_v150.exe': '1f1d8c966478ac41f0e95797ad177285218b3c3d470d23dd4daf5ec5e96223f0',
    'pc-windows/kit-2-dudect/extraire_cibles_v150.py': '6b07216e7838586529ee6b5a7e081a750ad71e9a738033804f625fcbc820843c',
    'pc-windows/kit-2-dudect/test_appel.c': '56a35ec0f085ceb855800b438ef8de8ca6a1ae681bdc8f9bb91fdf240dfc6174',
    'pc-windows/kit-2-dudect/test_appel.exe': '42903257aa9e3028df44ef77339ffa0f732116bae4806beb51b602c41e9e1e70',
    'pc-windows/kit-3-terrain-tiers-loupe/LANCER-KIT-3-LOUPE.bat': '0b447c0e713567ebc6fc09e52e9c1a2a03eab0e4d87453bd22daaa6e188148fb',
    'pc-windows/kit-3-terrain-tiers-loupe/LISEZMOI-terrain-tiers.txt': 'c6b83f31285c2be04f290b22335edcb4d848d17f860453b40841664bb9520660',
    'pc-windows/kit-3-terrain-tiers-loupe/loupe-kit-13/LISEZMOI-KIT-LOUPE.md': '241ab29498f450d7ccf38affcd347f611d9ff06a10de4f14b0c35eee0ee149a5',
    'pc-windows/kit-3-terrain-tiers-loupe/loupe-kit-13/loupe.exe': 'c111510535767a40b0122d4e42261c9d8e1ec10d94d95ef666fd76ceb93e61d1',
    'pc-windows/kit-3-terrain-tiers-loupe/loupe-kit-13/scenario-loupe.py': '131d0135850237927ef59315a722bd0f206ed7741f1830b0aaf68e0a720a845a',
    'pc-windows/kit-3-terrain-tiers-loupe/loupe-kit-13/temoin-vitrine.bat': '33763be44bd9687f71b549bb3784759a491129ebc58856edfe6fb8ff39b216fe',
    'qemu-wsl2/LISEZMOI-qemu.txt': '6eabfa0d88567bb40b2a517683e6244b18530c0221148bf7cb7b66faefc98f08',
    'qemu-wsl2/kit-m7d/LISEZMOI-KIT-M7D.md': 'fc3571dd73bdce7cc59fbe27269f4920593443083c1fda86e3cf32ccc5168fc6',
    'qemu-wsl2/kit-m7d/corpus': 'ec343b4e8bebf21c8b29a6da1a5eb022fb7b8e4b50ce95c5906734ef0b043799',
    'qemu-wsl2/kit-m7d/demo': 'e57fc74be2ea67ab4c05351d0b5e0b93b6147ec34f2fb7aabbfd1ab7f141cde9',
    'qemu-wsl2/kit-m7d/qemu-riscv64': 'f2bb9b35eb97fc6b67c43a65d944ea9dcd7b1908df95faf28cea68511e762dc5',
    'qemu-wsl2/kit-m7d/scenario-m7d.py': 'ed7fd23caef2911aefdcdc42b541079ecf06ab0b06797f5af6ee0e3c1dfe9a1c',
    'qemu-wsl2/lancer-voie1-m7d.sh': '173ab0db8b3e29bea8577d73b78e3ae0f89828e887d7ecc8efb955f28aa73f86',
    'qemu-wsl2/lancer-voie2-shani.sh': '18043df2d68960f2b44288cb09f9ef2e319ba1c84b5e46e5c68bc585db363765',
    'qemu-wsl2/preuves-shani-emulation-labo/VERDICT-run-shani.txt': '31d6f33a356e15ee128697fa0cb691655be34f6040564cde607e664dafcf0838',
    'qemu-wsl2/preuves-shani-emulation-labo/scenario-shani-journal.log': '6d6940b12e382d4b9a6f7180a3f626fb7516eafa8b8c447c86e0fe06b6f59851',
    'qemu-wsl2/preuves-shani-emulation-labo/temoin-shani.txt': '8f68f62af6a32c2a57d5463f30b2edead70e9c5df06447734bac06ae89316d51',
    'telephone-arm/kit-constat-arm/LISEZMOI-constat-arm.txt': '7509e593b1db352dee12be33e3420d4620809a2e57121c23f05e29d97b3f8817',
    'telephone-arm/kit-constat-arm/constat-arm.py': 'cfaf4473cd5c40d6ef6159dc85dc23ce92e48a5983baa0f3875bef1d8189fb6e',
    'telephone-arm/kit-constat-arm/lancer-kit-constat-arm.sh': '830793014fa2b56eb02296a8672cfafe1ee46944042bbc51ba018f060aac1081',
}

LIGNES = []


def dit(texte=""):
    print(texte)
    LIGNES.append(texte)


def main():
    ici = pathlib.Path(__file__).resolve().parent
    dit("=" * 66)
    dit(" LE VÉRIFICATEUR DU PAQUET — l'intégrité de VOTRE extraction")
    dit(" %d pièces recoupées contre le manifeste du laboratoire."
        % len(MANIFESTE))
    dit(" Un écart nommé est un RÉSULTAT (D189), jamais un échec à"
        " maquiller.")
    dit("=" * 66)
    vertes = 0
    ecarts = 0
    for chemin in sorted(MANIFESTE):
        attendu = MANIFESTE[chemin]
        piece = ici / chemin
        if not piece.is_file():
            dit("[ÉCART : ABSENTE]      %s  (extraction incomplète ?"
                " l'antivirus ?)" % chemin)
            ecarts += 1
            continue
        lu = hashlib.sha256(piece.read_bytes()).hexdigest()
        if lu != attendu:
            dit("[ÉCART : DIVERGENTE]   %s" % chemin)
            dit("    attendu : %s" % attendu)
            dit("    lu      : %s" % lu)
            ecarts += 1
        else:
            dit("[VERT] %s" % chemin)
            vertes += 1
    dit()
    dit("=" * 66)
    if ecarts == 0:
        dit(" LE BILAN : %d/%d pièces VERTES — l'extraction est la pièce"
            % (vertes, len(MANIFESTE)))
        dit(" du laboratoire. Vivez les kits (COMMENCER-ICI.bat), la"
            " feuille de route est CE-QUI-RESTE-A-FAIRE.txt.")
    else:
        dit(" LE BILAN : %d/%d pièces vertes, %d ÉCART(S) NOMMÉ(S) —"
            % (vertes, len(MANIFESTE), ecarts))
        dit(" renvoyez verification-paquet.txt TEL QUEL (D122) : le labo")
        dit(" recoupe sur pièces. Si un EXE manque : c'est l'ANTIVIRUS"
            " (un faux positif des exe de mesure), pas le paquet —")
        dit(" voyez CE-QUI-RESTE-A-FAIRE.txt, section LES DEUX TESTS NEUFS.")
    dit("=" * 66)
    with open(SORTIE, "w", encoding="utf-8") as f:
        f.write("\n".join(LIGNES) + "\n")
    print()
    print("[rapport] écrit : %s" % SORTIE)
    return 0 if ecarts == 0 else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as e:                          # noqa: BLE001 — nommé
        print("[ERREUR NOMMÉE] le vérificateur a fauté : %r" % e)
        sys.exit(2)
