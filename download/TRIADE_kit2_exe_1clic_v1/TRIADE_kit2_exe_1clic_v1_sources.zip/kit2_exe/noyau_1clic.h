/* noyau_1clic.h — l'interface du noyau portable de l'exe 1-clic kit-2. */

#ifndef NOYAU_1CLIC_H
#define NOYAU_1CLIC_H

#include <stddef.h>
#include "payload_kit2.h"

/* l'empreinte sha256 de `n' octets en `donnees', hex minuscule dans `sortie'
 * (65 octets, termine par NUL). */
void sha256_hex(const void *donnees, size_t n, char *sortie);

/* l'empreinte d'un FICHIER entier (flux, jamais charge en memoire entiere). */
int sha256_fichier_hex(const char *chemin, char *sortie);

/* le crc32 IEEE (poly reflechi 0xEDB88320), celui du format zip. */
unsigned long crc32_zip(const unsigned char *donnees, size_t n);

/* cree `chemin_zip' (methode store) avec les fichiers `chemins[i]' ranges
 * sous les noms `noms_zip[i]'. Retourne 0 si OK, 1 si un fichier manque,
 * 2 si l'ecriture du zip echoue. */
int zip_creer(const char *chemin_zip,
              const char *const *chemins, const char *const *noms_zip,
              int nb);

/* ecrit les TRIADE_NB_PIECES pieces du blob embarque vers `dest_dir' en
 * recoupant CHAQUE sha256 contre le manifeste. Retourne le nombre de
 * pieces VERTES ; une piece DIVERGENTE ou non ecrite est NOMMEE sur
 * stdout et compte pour 0. Les sous-dossiers (cibles/) sont crees. */
int extraire_et_verifier(const char *dest_dir);

/* le DEPOT.txt auto-portant du zip de preuves. Retourne 0 si OK. */
int construire_depot_txt(const char *chemin, const char *horodatage,
                         int rc_run, const char *nom_zip,
                         const char *argument_n);

/* l'horodatage UTC AAAAMMJJTHHMMSSZ (16 caracteres + NUL). */
void horodatage_utc(char *sortie, size_t taille);

#endif /* NOYAU_1CLIC_H */
