/* triade_kit2_1clic.c — LA COQUILLE WIN32 de l'exe 1-clic kit-2 dudect
 * (13/11/2026, la commande du développeur : « je ne souhaite pas un apk en
 * 1 clic mais un exe en 1 clic pour le kit-2 » — le même geste court que
 * l'APK kit android, pour la partie pc-windows du paquet CORRECTIF2).
 *
 * LE GESTE : DOUBLE-CLIC. Rien d'autre. Aucun Python, aucun paquet à
 * extraire, aucune commande. L'exe porte le kit SCELLÉ en lui (les 10 pièces
 * du paquet CORRECTIF2 du coffre, octet pour octet) et :
 *   [1] écrit le kit vers %LOCALAPPDATA%\TRIADE\kit-2-dudect en recoupant
 *       CHAQUE sha256 (fail-closed : REFUS nommé si UN octet diverge —
 *       l'antivirus qui retirerait un exe de mesure est NOMMÉ, jamais un
 *       silence) ;
 *   [2] archive les restes du run précédent vers archives\<horodatage>
 *       (D99 : jamais de mélange de runs) ;
 *   [3] VIT LE VRAI LANCEUR DU KIT : cmd /c LANCER-KIT-2-DUDECT.bat — le
 *       .bat scellé fait TOUT (recoup de l'image scellée, recompilation si
 *       un compilateur vit, sinon les exe précompilés livrés, l'épreuve
 *       d'appel FIPS abc, LE RUN N=200, le brouillon de témoin) ; sa
 *       console ENTIÈRE est capturée dans run-console-<ts>.txt puis
 *       affichée telle quelle ;
 *   [4] construit le zip des preuves sur le Bureau (journal csv, sorties,
 *       témoin, console, DEPOT.txt) ;
 *   [5] ouvre l'explorateur SUR LE ZIP et le coffre /test du Drive dans le
 *       navigateur — le dépôt est VOTRE geste : AUCUN jeton dans cet exe
 *       (la frontière du GUI v1 et de l'APK kit android).
 *
 * L'HONNÊTETÉ : l'exe NE MESURE RIEN et ne modifie JAMAIS le kit — la
 * mesure vit dans dudect_v150, l'épreuve dans test_appel, le protocole dans
 * le .bat : les sorties et codes de sortie sont LES LEURS. Le labo n'a
 * aucun Windows : le noyau (sha256, zip, extraction) fut éprouvé à
 * l'autotest POSIX + recoup Python octet-exact ; la coquille Win32 vit son
 * premier run chez vous, comme les exe précompilés du kit avant vous. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <shlobj.h>

#include "noyau_1clic.h"

#define DOSSIER_TRIADE "TRIADE"
#define DOSSIER_KIT    "kit-2-dudect"
#define URL_COFRE_TEST "https://drive.google.com/drive/folders/1KeJIMwpsT7GshcjIJy0Sf8KzsOBjimU0"

/* les restes d'un run du kit (ce que le .bat et l'exe y écrivent) —
 * archivés D99 avant le run suivant, jamais mélangés */
static const char *RESTES_RUN[] = {
    "sortie-run.txt",
    "sortie-appel.txt",
    "temoin-dudect-BROUILLON.txt",
    "journal-dudect-",
    "run-console-",
    "DEPOT-",
    NULL,
};

static void pause_console(void)
{
    printf("\n");
    system("pause");
}

static int creer_rep(const char *chemin)
{
    if (CreateDirectoryA(chemin, NULL)) return 1;
    return GetLastError() == ERROR_ALREADY_EXISTS;
}

/* remplace '/' par '\\' sur place (cmd.exe exige les antislashs). */
static void dosifier(char *s)
{
    for (; *s; s++)
        if (*s == '/') *s = '\\';
}

static int construire_chemin_kit(char *sortie, size_t taille)
{
    const char *base = getenv("LOCALAPPDATA");
    if (!base || !base[0]) base = getenv("TEMP");
    if (!base || !base[0]) base = ".";
    if (strlen(base) + strlen(DOSSIER_TRIADE) + strlen(DOSSIER_KIT) + 3 > taille)
        return 0;
    sprintf(sortie, "%s\\%s\\%s", base, DOSSIER_TRIADE, DOSSIER_KIT);
    return 1;
}

/* [2] D99 : les restes du run précédent partent aux archives horodatées. */
static int archiver_run_precedent(const char *dir_kit, const char *horodatage)
{
    char dir_archives[1024];
    char dir_run[1200];
    WIN32_FIND_DATAA ffd;
    HANDLE h;
    int deplacees = 0;
    int i;

    snprintf(dir_archives, sizeof(dir_archives), "%s\\archives", dir_kit);
    snprintf(dir_run, sizeof(dir_run), "%s\\%s", dir_archives, horodatage);
    for (i = 0; RESTES_RUN[i]; i++) {
        char motif[1400];
        snprintf(motif, sizeof(motif), "%s\\%s*", dir_kit, RESTES_RUN[i]);
        h = FindFirstFileA(motif, &ffd);
        if (h == INVALID_HANDLE_VALUE) continue;
        do {
            char source[1500];
            char cible[1600];
            if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
            snprintf(source, sizeof(source), "%s\\%s", dir_kit, ffd.cFileName);
            creer_rep(dir_archives);
            creer_rep(dir_run);
            snprintf(cible, sizeof(cible), "%s\\%s", dir_run, ffd.cFileName);
            if (MoveFileA(source, cible)) deplacees++;
        } while (FindNextFileA(h, &ffd));
        FindClose(h);
    }
    return deplacees;
}

/* [3] LE RUN : cmd /c le .bat scellé, console entière capturée. Retour :
 * le code de sortie du .bat, ou -1 si le processus n'a pas pu naître. */
static int lancer_le_kit(const char *dir_kit, const char *horodatage,
                         const char *argument_n, char *chemin_console,
                         size_t taille_console)
{
    char bat[1024];
    char ligne[2200];
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    SECURITY_ATTRIBUTES sa;
    HANDLE h_console = INVALID_HANDLE_VALUE;
    HANDLE h_nul = INVALID_HANDLE_VALUE;
    DWORD rc = 2;

    snprintf(bat, sizeof(bat), "%s\\LANCER-KIT-2-DUDECT.bat", dir_kit);
    dosifier(bat);
    snprintf(chemin_console, taille_console, "%s\\run-console-%s.txt",
             dir_kit, horodatage);

    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    h_console = CreateFileA(chemin_console, GENERIC_WRITE, FILE_SHARE_READ,
                            &sa, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    h_nul = CreateFileA("NUL", GENERIC_READ,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        &sa, OPEN_EXISTING, 0, NULL);
    if (h_console == INVALID_HANDLE_VALUE)
        printf("  [ecart nomme] capture de console impossible (%lu) : le kit\n"
               "                vivra sans capture, ses sorties restent les siennes.\n",
               (unsigned long)GetLastError());

    if (argument_n && argument_n[0])
        snprintf(ligne, sizeof(ligne), "cmd.exe /c \"\"%s\" %s\"", bat, argument_n);
    else
        snprintf(ligne, sizeof(ligne), "cmd.exe /c \"\"%s\"\"", bat);

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = (h_nul != INVALID_HANDLE_VALUE)
                   ? h_nul : GetStdHandle(STD_INPUT_HANDLE);
    si.hStdOutput = (h_console != INVALID_HANDLE_VALUE)
                    ? h_console : GetStdHandle(STD_OUTPUT_HANDLE);
    si.hStdError = si.hStdOutput;
    ZeroMemory(&pi, sizeof(pi));

    if (!CreateProcessA(NULL, ligne, NULL, NULL, TRUE, 0, NULL, dir_kit,
                        &si, &pi)) {
        printf("  [REFUS nomme] CreateProcess impossible (%lu) - RIEN ne court.\n",
               (unsigned long)GetLastError());
        if (h_console != INVALID_HANDLE_VALUE) CloseHandle(h_console);
        if (h_nul != INVALID_HANDLE_VALUE) CloseHandle(h_nul);
        return -1;
    }
    WaitForSingleObject(pi.hProcess, INFINITE);
    GetExitCodeProcess(pi.hProcess, &rc);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    if (h_console != INVALID_HANDLE_VALUE) CloseHandle(h_console);
    if (h_nul != INVALID_HANDLE_VALUE) CloseHandle(h_nul);
    return (int)rc;
}

/* le journal csv le plus récent (celui du run qui vient de vivre). */
static int trouver_journal(const char *dir_kit, char *sortie, size_t taille)
{
    WIN32_FIND_DATAA ffd;
    HANDLE h;
    FILETIME meilleur;
    char motif[1400];
    int trouve = 0;
    ZeroMemory(&meilleur, sizeof(meilleur));
    snprintf(motif, sizeof(motif), "%s\\journal-dudect-*.csv", dir_kit);
    h = FindFirstFileA(motif, &ffd);
    if (h == INVALID_HANDLE_VALUE) return 0;
    do {
        if (CompareFileTime(&ffd.ftLastWriteTime, &meilleur) > 0) {
            meilleur = ffd.ftLastWriteTime;
            snprintf(sortie, taille, "%s\\%s", dir_kit, ffd.cFileName);
            trouve = 1;
        }
    } while (FindNextFileA(h, &ffd));
    FindClose(h);
    return trouve;
}

static void afficher_fichier(const char *chemin)
{
    FILE *f = fopen(chemin, "rb");
    char tampon[4096];
    size_t lu;
    if (!f) return;
    printf("\n------ la console du kit, telle quelle ------\n");
    while ((lu = fread(tampon, 1, sizeof(tampon), f)) > 0)
        fwrite(tampon, 1, lu, stdout);
    printf("------ fin de la console du kit --------------\n");
    fclose(f);
}

int main(int argc, char **argv)
{
    char dir_kit[1024];
    char horodatage[32];
    char argument_n[64] = "";
    char chemin_console[1300];
    char bureau[1024];
    char chemin_zip[2100];
    char chemin_depot[1300];
    const char *sources[8];
    const char *noms_zip[8];
    char nom_console_zip[256];
    char nom_journal_zip[256];
    char chemin_journal[1300];
    char p_sortie_run[1100], p_sortie_appel[1100], p_temoin[1100];
    int nb_pieces;
    int rc_run;
    int nb_zip = 0;
    int i;

    SetConsoleTitleA("TRIADE - kit 2 dudect en 1 clic (paquet CORRECTIF2 du coffre)");

    printf("============================================================================\n");
    printf(" TRIADE - LE KIT 2 DUDECT EN 1 CLIC v1 (pc-windows du paquet CORRECTIF2)\n");
    printf(" Les quatre familles crypto de la piece scellee (tls13-02, tls13-13,\n");
    printf(" tls13-16, tls13-17), RDTSC/QPC, affinite coeur 0, t de Welch, |t| > 5.\n");
    printf(" LE KIT EST EN MOI : les 10 pieces du paquet du coffre, octet pour octet,\n");
    printf(" re-recoupees par sha256 a CHAQUE run (fail-closed). Aucun Python requis.\n");
    printf("============================================================================\n\n");

    if (argc > 1) {
        strncpy(argument_n, argv[1], sizeof(argument_n) - 1);
        argument_n[sizeof(argument_n) - 1] = '\0';
        printf("[protocole] N passe en argument : %s (le lanceur du kit valide : minimum 60)\n\n",
               argument_n);
    }

    horodatage_utc(horodatage, sizeof(horodatage));
    if (!construire_chemin_kit(dir_kit, sizeof(dir_kit))) {
        printf("[REFUS nomme] le chemin du kit serait trop long - RIEN ne court.\n");
        pause_console();
        return 2;
    }
    dosifier(dir_kit);
    {
        char dir_parent[1024];
        strcpy(dir_parent, dir_kit);
        for (i = (int)strlen(dir_parent) - 1; i > 0; i--)
            if (dir_parent[i] == '\\') { dir_parent[i] = '\0'; break; }
        creer_rep(dir_parent);   /* %LOCALAPPDATA%\TRIADE */
    }

    printf("[1/5] LE KIT SCELLE VERS :\n      %s\n", dir_kit);
    nb_pieces = extraire_et_verifier(dir_kit);
    printf("\n");
    if (nb_pieces != TRIADE_NB_PIECES) {
        printf("[REFUS nomme] %d/%d pieces VERTES seulement - un octet diverge\n",
               nb_pieces, TRIADE_NB_PIECES);
        printf("        ou une piece manque (l'antivirus ? le coffre Drive l'a vecu le\n");
        printf("        12/11 : un faux positif des exe de mesure de timing). RIEN ne court.\n");
        printf("        Conduite : autorisez le dossier TRIADE dans l'antivirus, puis\n");
        printf("        relancez CET exe - le kit se re-extrait et se re-recoupe.\n");
        pause_console();
        return 2;
    }
    printf("      %d/%d pieces VERTES : la piece est la piece du labo, le run peut vivre.\n\n",
           nb_pieces, TRIADE_NB_PIECES);

    printf("[2/5] D99 - les restes du run precedent partent aux archives\n");
    {
        int deplacees = archiver_run_precedent(dir_kit, horodatage);
        if (deplacees > 0)
            printf("      %d piece(s) deplacee(s) vers archives\\%s\\\n\n",
                   deplacees, horodatage);
        else
            printf("      aucun reste de run precedent : dossier propre.\n\n");
    }

    printf("[3/5] LE RUN - le VRAI lanceur du kit vit maintenant :\n");
    printf("      cmd /c LANCER-KIT-2-DUDECT.bat %s\n",
           argument_n[0] ? argument_n : "(N = 200 par defaut)");
    printf("      (sa console est capturee dans run-console-%s.txt, l'affichage suit\n",
           horodatage);
    printf("       a la fin du run - quelques instants...)\n\n");
    rc_run = lancer_le_kit(dir_kit, horodatage,
                           argument_n[0] ? argument_n : NULL,
                           chemin_console, sizeof(chemin_console));
    if (rc_run < 0) {
        pause_console();
        return 2;
    }

    afficher_fichier(chemin_console);

    printf("\n[4/5] LES PREUVES - le zip des preuves se construit\n");
    snprintf(p_sortie_run, sizeof(p_sortie_run), "%s\\sortie-run.txt", dir_kit);
    snprintf(p_sortie_appel, sizeof(p_sortie_appel), "%s\\sortie-appel.txt", dir_kit);
    snprintf(p_temoin, sizeof(p_temoin), "%s\\temoin-dudect-BROUILLON.txt", dir_kit);
    snprintf(chemin_depot, sizeof(chemin_depot), "%s\\DEPOT-%s.txt",
             dir_kit, horodatage);

    if (SHGetFolderPathA(NULL, CSIDL_DESKTOPDIRECTORY, NULL, 0, bureau) != S_OK)
        strcpy(bureau, dir_kit);   /* repli : le dossier du kit */
    snprintf(chemin_zip, sizeof(chemin_zip), "%s\\preuves-kit2-dudect-%s.zip",
             bureau, horodatage);

    if (construire_depot_txt(chemin_depot, horodatage, rc_run,
                             "preuves-kit2-dudect.zip",
                             argument_n[0] ? argument_n : NULL) != 0)
        printf("      [ecart nomme] DEPOT.txt non ecrit - le zip vivra sans lui.\n");

    nb_zip = 0;
    /* la console entiere du lanceur du kit */
    snprintf(nom_console_zip, sizeof(nom_console_zip), "run-console-%s.txt",
             horodatage);
    sources[nb_zip] = chemin_console;
    noms_zip[nb_zip] = nom_console_zip;
    nb_zip++;
    /* le journal csv du run qui vient de vivre */
    if (trouver_journal(dir_kit, chemin_journal, sizeof(chemin_journal))) {
        snprintf(nom_journal_zip, sizeof(nom_journal_zip), "preuves-kit2/%s",
                 chemin_journal + strlen(dir_kit) + 1);
        sources[nb_zip] = chemin_journal;
        noms_zip[nb_zip] = nom_journal_zip;
        nb_zip++;
    }
    /* les sorties du kit, si elles vivent */
    {
        const char *couples[3][2] = {
            { p_sortie_run, "preuves-kit2/sortie-run.txt" },
            { p_sortie_appel, "preuves-kit2/sortie-appel.txt" },
            { p_temoin, "preuves-kit2/temoin-dudect-BROUILLON.txt" },
        };
        for (i = 0; i < 3; i++) {
            FILE *probe = fopen(couples[i][0], "rb");
            if (probe) {
                fclose(probe);
                sources[nb_zip] = couples[i][0];
                noms_zip[nb_zip] = couples[i][1];
                nb_zip++;
            }
        }
    }
    sources[nb_zip] = chemin_depot;
    noms_zip[nb_zip] = "DEPOT.txt";
    nb_zip++;

    {
        int rz = zip_creer(chemin_zip, sources, noms_zip, nb_zip);
        if (rz == 0)
            printf("      ECRIT : %s (%d pieces)\n", chemin_zip, nb_zip);
        else {
            printf("      [ecart nomme] le zip des preuves a echoue (code %d) -\n", rz);
            printf("      les pieces restent dans le dossier du kit :\n      %s\n", dir_kit);
        }
    }

    printf("\n[5/5] LE DEPOT - l'explorateur OUVERT sur le zip, le coffre /test\n");
    printf("      OUVERT dans le navigateur : DEPOSEZ le zip au coffre\n");
    printf("      (dossier Drive \"Triade\" - \"test\"). AUCUN jeton dans cet exe :\n");
    printf("      le depot est VOTRE geste, comme au GUI et a l'APK.\n");
    {
        char sel[2300];
        snprintf(sel, sizeof(sel), "/select,\"%s\"", chemin_zip);
        ShellExecuteA(NULL, "open", "explorer.exe", sel, NULL, SW_SHOWNORMAL);
        ShellExecuteA(NULL, "open", URL_COFRE_TEST, NULL, NULL, SW_SHOWNORMAL);
    }

    printf("\n============================================================================\n");
    printf(" LE RUN EST VECU. Code de sortie du lanceur du kit : %d\n", rc_run);
    printf(" (0 = tout a vecu jusqu'au bout ; 2 = refus nomme du lanceur ; le code\n");
    printf("  du mesureur et la lecture honnete vivent dans sortie-run.txt, le\n");
    printf("  temoin et le LISEZMOI du kit.)\n");
    printf(" A VOTRE MAIN : completez temoin-dudect-BROUILLON.txt dans le zip (l'etat\n");
    printf(" EFFECTIF du turbo, vos observations memes defavorables - D189), datez et\n");
    printf(" signez, deposez le zip. |t| > 5 = dependance AU SEUIL consignee telle\n");
    printf(" quelle ; |t| <= 5 = aucune divergence au seuil sur CET echantillon, CETTE\n");
    printf(" machine - jamais \"temps constant prouve\".\n");
    printf("============================================================================\n");

    pause_console();
    return rc_run;
}
