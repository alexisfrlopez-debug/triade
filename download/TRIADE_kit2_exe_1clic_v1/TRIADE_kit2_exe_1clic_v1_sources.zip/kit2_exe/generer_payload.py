#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""generer_payload.py — génère payload_kit2.c : les 10 pièces du kit-2 dudect
du paquet CORRECTIF2 (octet pour octet) en un blob C + manifeste sha256.

Le kit embarqué est JAMAIS MODIFIÉ : les octets du zip du coffre deviennent
le tableau C tel quel ; le manifeste porte le sha256 hashlib de chaque pièce
(la référence), que le noyau C re-recoupe à l'extraction (fail-closed).
"""
import hashlib
import pathlib
import sys

KIT = pathlib.Path("/home/z/my-project/scripts/tmp/kit2_corrige/pc-windows/kit-2-dudect")
OUT = pathlib.Path("/home/z/my-project/scripts/kit2_exe/gen")

PIECES = [
    "LANCER-KIT-2-DUDECT.bat",
    "LISEZMOI-dudect.txt",
    "dudect_v150.c",
    "dudect_v150.exe",
    "extraire_cibles_v150.py",
    "test_appel.c",
    "test_appel.exe",
    "cibles/manifeste-c.txt",
    "cibles/manifeste.json",
    "cibles/proxy-image.bin",
]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    blob = bytearray()
    manifeste = []
    for nom in PIECES:
        data = (KIT / nom).read_bytes()
        manifeste.append((nom, len(blob), len(data),
                          hashlib.sha256(data).hexdigest()))
        blob += data

    lignes = []
    lignes.append("/* payload_kit2.c - GENERE par generer_payload.py - NE PAS EDITER.")
    lignes.append(" * Les 10 pieces du kit-2 dudect, paquet CORRECTIF2 du coffre,")
    lignes.append(" * octet pour octet (%d octets au total). */" % len(blob))
    lignes.append("#include <stddef.h>")
    lignes.append("")
    lignes.append("struct piece_kit { const char *nom; long offset; long taille; const char *sha256; };")
    lignes.append("")
    lignes.append("#define TRIADE_NB_PIECES %d" % len(manifeste))
    lignes.append("#define TRIADE_TAILLE_BLOB %d" % len(blob))
    lignes.append("")
    lignes.append("const unsigned char TRIADE_BLOB[%d] = {" % len(blob))
    for i in range(0, len(blob), 16):
        morceaux = blob[i:i + 16]
        lignes.append("    " + " ".join("0x%02x," % b for b in morceaux))
    lignes.append("};")
    lignes.append("")
    lignes.append("const struct piece_kit TRIADE_MANIFESTE[TRIADE_NB_PIECES] = {")
    for nom, off, taille, sha in manifeste:
        lignes.append('    {"%s", %d, %d, "%s"},' % (nom, off, taille, sha))
    lignes.append("};")
    (OUT / "payload_kit2.c").write_text("\n".join(lignes) + "\n",
                                        encoding="ascii")

    entete = [
        "/* payload_kit2.h - GENERE par generer_payload.py - NE PAS EDITER. */",
        "#ifndef PAYLOAD_KIT2_H",
        "#define PAYLOAD_KIT2_H",
        "",
        "struct piece_kit { const char *nom; long offset; long taille; const char *sha256; };",
        "",
        "#define TRIADE_NB_PIECES %d" % len(manifeste),
        "#define TRIADE_TAILLE_BLOB %d" % len(blob),
        "",
        "extern const unsigned char TRIADE_BLOB[TRIADE_TAILLE_BLOB];",
        "extern const struct piece_kit TRIADE_MANIFESTE[TRIADE_NB_PIECES];",
        "",
        "#endif /* PAYLOAD_KIT2_H */",
    ]
    (OUT / "payload_kit2.h").write_text("\n".join(entete) + "\n",
                                        encoding="ascii")
    print("[payload] en-tete : %s" % (OUT / "payload_kit2.h"))

    print("[payload] %d pièces, %d octets" % (len(manifeste), len(blob)))
    for nom, off, taille, sha in manifeste:
        print("    %-28s %8d o  sha256 %s…" % (nom, taille, sha[:16]))
    print("[payload] écrit : %s" % (OUT / "payload_kit2.c"))


if __name__ == "__main__":
    sys.exit(main())
