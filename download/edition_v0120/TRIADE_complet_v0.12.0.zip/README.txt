TRIADE — ÉDITION ACADÉMIQUE v0.12.0 — ARCHIVE COMPLÈTE
======================================================

L'intégralité de la troisième édition : le manuscrit final ET ses
sources, la spécification v0.12.0 et sa chaîne LaTeX, LE MODÈLE FORMEL
(le script est le modèle) AVEC ses sorties brutes, l'analyse SPRT de la
cristallisation, LE PROTOCOLE DE RÉPLICATION, les instruments v0.11.0
avec leurs sorties (mutation, fuzzage, sûreté mémoire, temps constant,
benchmarks, indépendance), les données des trois éditions, le constat
du rejeu intégral, les extraits de journal et les empreintes.

Arborescence :
  README.txt                       ce guide
  manuscrit/                       le PDF + sources + données
  specification/                   le PDF v0.12.0 + la chaîne spec_v120
  instruments/                     modele_formel_v120.py (LE MODÈLE) +
                                   cristallisation_v120.py (LE SPRT)
  instruments/sorties_v120/        les sorties brutes du vérificateur +
                                   le protocole de réplication
  instruments/sorties_v110/        les six instruments v0.11.0 + sorties
  journal/                         les extraits + le rejeu intégral
  journal/decisions_D187-D189.md   les décisions du modèle formel
  journal/entree_225.md            l'entrée du journal
  VERIFICATION_v0.12.0.txt         le constat de vérification
  empreintes_complet.txt           sha-256 de tout ce qui précède

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
