TRIADE — ÉDITION ACADÉMIQUE v0.12.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers, le maximum exigé) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.12.0.pdf    — le manuscrit IMRAD (l'édition
     finale : § 4.5 les preuves renforcées, § 4.6 le modèle formel de
     CF3 et ses quatre propriétés, le modèle de menace en deux plans,
     la cristallisation, le protocole de réplication) ;
  3. tableaux_donnees_v0.12.0.csv    — TOUS les tableaux des TROIS
     éditions (v0.10.0, v0.11.0, v0.12.0) — générés, jamais tapés ;
  4. empreintes_soumission.txt       — les empreintes sha-256 ;
  5. VERIFICATION_v0.12.0.txt        — le constat : le modèle formel
     exécuté (sorties brutes), les autotests CF2/CF3/sceau, le rejeu
     intégral des harnais, le garde du sceau 14/14, l'audit de
     gouvernance.

Les résultats v0.12.0 :
  - CF3 formellement vérifié : les QUATRE propriétés PROUVÉES DANS LE
    MODÈLE (secret sous seuil ≤ 2 éléments, refus du roll-back, pas de
    destruction sur phrase erronée, rayon borné à une époque) — 154
    états, 1 152 transitions, hypothèses d'adversaire A1-A5 explicites,
    le hors modèle nommé ;
  - le modèle de menace restructuré en DEUX PLANS (IP / sûreté
    d'exécution) avec l'ordre intra-sécurité explicite et la tension
    D81↔D183 chiffrée (facteur ≈ 40 — D81 demeure) ;
  - la cristallisation justifiée par le SPRT (le seuil 10 atteint
    α = 1,08 × 10⁻³, 46× plus strict — le seuil demeure) ;
  - le protocole de réplication proposé (grille T/X, double annotation,
    κ de Cohen ≥ 0,61) — jamais exécuté : N = 1 demeure la limite
    déclarée.

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
