/* noyau_1clic.c — le noyau portable de l'exe 1-clic kit-2 dudect (13/11/2026).
 *
 * TOUT ce qui fait le travail est ICI, en C portable (mingw-w64 Windows ET
 * gcc POSIX — le même code, éprouvé à l'autotest POSIX du labo, à la
 * tradition du kit : le backend POSIX valide ce que Windows vivra) :
 *   - sha256 : l'empreinte de chaque pièce extraite, re-recoupée contre le
 *     manifeste (fail-closed : REFUS nommé si UN octet diverge) ;
 *   - crc32 + zip_creer : le zip des preuves (méthode store, sans aucune
 *     dépendance — lisible par l'explorateur Windows, unzip, Python) ;
 *   - extraire_et_verifier : écrit les pièces du blob embarqué vers le
 *     dossier du kit, en recoupant CHAQUE sha256 à l'écriture même ;
 *   - construire_depot_txt : le DEPOT.txt auto-portant du zip de preuves.
 *
 * Les pièces embarquées sont JAMAIS MODIFIÉES : octet pour octet le paquet
 * CORRECTIF3 du coffre (voyez generer_payload.py). */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "noyau_1clic.h"
#include "payload_kit2.h"

/* ============================== SHA-256 ============================== */
/* L'implémentation FIPS 180-4 classique (mots 32 bits, gros boutisme). */

typedef struct {
    unsigned int etat[8];
    unsigned long long nb_bits;
    unsigned char tampon[64];
    unsigned int dans_tampon;
} sha256_ctx;

static const unsigned int SHA_K[64] = {
    0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u,
    0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
    0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
    0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
    0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu,
    0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
    0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u,
    0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
    0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
    0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
    0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u,
    0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
    0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u,
    0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
    0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
    0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u,
};

#define ROR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))

static void sha256_bloc(sha256_ctx *c, const unsigned char *p)
{
    unsigned int w[64], a, b, cc, d, e, f, g, h, t1, t2;
    int i;
    for (i = 0; i < 16; i++)
        w[i] = ((unsigned int)p[i * 4] << 24)
             | ((unsigned int)p[i * 4 + 1] << 16)
             | ((unsigned int)p[i * 4 + 2] << 8)
             | (unsigned int)p[i * 4 + 3];
    for (i = 16; i < 64; i++) {
        unsigned int s0 = ROR(w[i - 15], 7) ^ ROR(w[i - 15], 18) ^ (w[i - 15] >> 3);
        unsigned int s1 = ROR(w[i - 2], 17) ^ ROR(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    a = c->etat[0]; b = c->etat[1]; cc = c->etat[2]; d = c->etat[3];
    e = c->etat[4]; f = c->etat[5]; g = c->etat[6]; h = c->etat[7];
    for (i = 0; i < 64; i++) {
        unsigned int S1 = ROR(e, 6) ^ ROR(e, 11) ^ ROR(e, 25);
        unsigned int ch = (e & f) ^ ((~e) & g);
        unsigned int S0 = ROR(a, 2) ^ ROR(a, 13) ^ ROR(a, 22);
        unsigned int maj = (a & b) ^ (a & cc) ^ (b & cc);
        t1 = h + S1 + ch + SHA_K[i] + w[i];
        t2 = S0 + maj;
        h = g; g = f; f = e; e = d + t1;
        d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->etat[0] += a; c->etat[1] += b; c->etat[2] += cc; c->etat[3] += d;
    c->etat[4] += e; c->etat[5] += f; c->etat[6] += g; c->etat[7] += h;
}

static void sha256_init(sha256_ctx *c)
{
    c->etat[0] = 0x6a09e667u; c->etat[1] = 0xbb67ae85u;
    c->etat[2] = 0x3c6ef372u; c->etat[3] = 0xa54ff53au;
    c->etat[4] = 0x510e527fu; c->etat[5] = 0x9b05688cu;
    c->etat[6] = 0x1f83d9abu; c->etat[7] = 0x5be0cd19u;
    c->nb_bits = 0;
    c->dans_tampon = 0;
}

static void sha256_update(sha256_ctx *c, const void *donnees, size_t n)
{
    const unsigned char *p = (const unsigned char *)donnees;
    c->nb_bits += (unsigned long long)n * 8ULL;
    while (n > 0) {
        size_t prendre = 64 - c->dans_tampon;
        if (prendre > n) prendre = n;
        memcpy(c->tampon + c->dans_tampon, p, prendre);
        c->dans_tampon += (unsigned int)prendre;
        p += prendre; n -= prendre;
        if (c->dans_tampon == 64) {
            sha256_bloc(c, c->tampon);
            c->dans_tampon = 0;
        }
    }
}

static void sha256_final(sha256_ctx *c, unsigned char sortie[32])
{
    unsigned long long bits = c->nb_bits;
    unsigned char pad[72];
    unsigned int i;
    size_t pad_len;
    unsigned char fin[8];

    pad_len = (c->dans_tampon < 56) ? (56 - c->dans_tampon) : (120 - c->dans_tampon);
    memset(pad, 0, sizeof(pad));
    pad[0] = 0x80;
    for (i = 0; i < 8; i++)
        fin[i] = (unsigned char)((bits >> (56 - 8 * i)) & 0xff);
    sha256_update(c, pad, pad_len);
    sha256_update(c, fin, 8);
    /* le update ci-dessus a modifie nb_bits — sans effet, on lit l'etat */
    for (i = 0; i < 8; i++) {
        sortie[i * 4]     = (unsigned char)((c->etat[i] >> 24) & 0xff);
        sortie[i * 4 + 1] = (unsigned char)((c->etat[i] >> 16) & 0xff);
        sortie[i * 4 + 2] = (unsigned char)((c->etat[i] >> 8) & 0xff);
        sortie[i * 4 + 3] = (unsigned char)(c->etat[i] & 0xff);
    }
}

void sha256_hex(const void *donnees, size_t n, char *sortie)
{
    sha256_ctx c;
    unsigned char resume[32];
    unsigned int i;
    static const char HEX[] = "0123456789abcdef";
    sha256_init(&c);
    sha256_update(&c, donnees, n);
    sha256_final(&c, resume);
    for (i = 0; i < 32; i++) {
        sortie[i * 2] = HEX[resume[i] >> 4];
        sortie[i * 2 + 1] = HEX[resume[i] & 0x0f];
    }
    sortie[64] = '\0';
}

int sha256_fichier_hex(const char *chemin, char *sortie)
{
    FILE *f = fopen(chemin, "rb");
    sha256_ctx c;
    unsigned char resume[32];
    unsigned char tampon[16384];
    size_t lu;
    unsigned int i;
    static const char HEX[] = "0123456789abcdef";
    if (!f) return -1;
    sha256_init(&c);
    while ((lu = fread(tampon, 1, sizeof(tampon), f)) > 0)
        sha256_update(&c, tampon, lu);
    if (ferror(f)) { fclose(f); return -1; }
    fclose(f);
    sha256_final(&c, resume);
    for (i = 0; i < 32; i++) {
        sortie[i * 2] = HEX[resume[i] >> 4];
        sortie[i * 2 + 1] = HEX[resume[i] & 0x0f];
    }
    sortie[64] = '\0';
    return 0;
}

/* =============================== CRC32 =============================== */

unsigned long crc32_zip(const unsigned char *donnees, size_t n)
{
    static unsigned long table[256];
    static int table_prete = 0;
    unsigned long crc;
    size_t i;
    if (!table_prete) {
        unsigned long c;
        int k, j;
        for (k = 0; k < 256; k++) {
            c = (unsigned long)k;
            for (j = 0; j < 8; j++)
                c = (c & 1) ? (0xedb88320UL ^ (c >> 1)) : (c >> 1);
            table[k] = c;
        }
        table_prete = 1;
    }
    crc = 0xffffffffUL;
    for (i = 0; i < n; i++)
        crc = table[(crc ^ donnees[i]) & 0xff] ^ (crc >> 8);
    return crc ^ 0xffffffffUL;
}

/* ============================ ZIP (store) ============================ */

static void ecrire_u16(FILE *f, unsigned int v)
{
    fputc((int)(v & 0xff), f);
    fputc((int)((v >> 8) & 0xff), f);
}

static void ecrire_u32(FILE *f, unsigned long v)
{
    fputc((int)(v & 0xff), f);
    fputc((int)((v >> 8) & 0xff), f);
    fputc((int)((v >> 16) & 0xff), f);
    fputc((int)((v >> 24) & 0xff), f);
}

/* le crc32 d'un FICHIER entier, en un seul etat de CRC chainé (crc32
 * n'est PAS associatif par morceaux — un seul flux, memoire tampon 16 Ko). */
static unsigned long crc32_fichier(const char *chemin, int *err)
{
    FILE *src = fopen(chemin, "rb");
    unsigned char tampon[16384];
    size_t lu;
    unsigned long crc = 0xffffffffUL;
    static unsigned long table[256];
    static int table_prete = 0;
    size_t i;
    *err = 0;
    if (!src) { *err = 1; return 0; }
    if (!table_prete) {
        unsigned long c;
        int k, j;
        for (k = 0; k < 256; k++) {
            c = (unsigned long)k;
            for (j = 0; j < 8; j++)
                c = (c & 1) ? (0xedb88320UL ^ (c >> 1)) : (c >> 1);
            table[k] = c;
        }
        table_prete = 1;
    }
    while ((lu = fread(tampon, 1, sizeof(tampon), src)) > 0) {
        for (i = 0; i < lu; i++)
            crc = table[(crc ^ tampon[i]) & 0xff] ^ (crc >> 8);
    }
    if (ferror(src)) { *err = 1; }
    fclose(src);
    return crc ^ 0xffffffffUL;
}

int zip_creer(const char *chemin_zip,
              const char *const *chemins, const char *const *noms_zip,
              int nb)
{
    FILE *z = fopen(chemin_zip, "wb");
    unsigned long *crcs, *tailles, *offsets;
    int k;
    unsigned long pos_central;

    if (!z) return 2;
    crcs = (unsigned long *)calloc((size_t)nb, sizeof(unsigned long));
    tailles = (unsigned long *)calloc((size_t)nb, sizeof(unsigned long));
    offsets = (unsigned long *)calloc((size_t)nb, sizeof(unsigned long));
    if (!crcs || !tailles || !offsets) {
        free(crcs); free(tailles); free(offsets); fclose(z); return 2;
    }

    for (k = 0; k < nb; k++) {
        int err = 0;
        unsigned long crc = crc32_fichier(chemins[k], &err);
        FILE *src;
        unsigned char tampon[16384];
        size_t lu;
        unsigned long taille = 0;
        if (err) {
            free(crcs); free(tailles); free(offsets); fclose(z); return 1;
        }
        offsets[k] = (unsigned long)ftell(z);
        /* en-tete local : signature, version, drapeaux, methode 0 (store),
         * heure/date DOS, crc, tailles, nom, extra 0 */
        ecrire_u32(z, 0x04034b50UL);
        ecrire_u16(z, 20);
        ecrire_u16(z, 0);
        ecrire_u16(z, 0);
        ecrire_u16(z, 0);          /* heure : 00:00:00 (voir note date) */
        ecrire_u16(z, 0x21);       /* date : 1980-01-01 */
        ecrire_u32(z, crc);
        ecrire_u32(z, 0);          /* csize : remplace ci-dessous */
        ecrire_u32(z, 0);          /* usize : idem */
        ecrire_u16(z, (unsigned int)strlen(noms_zip[k]));
        ecrire_u16(z, 0);
        fwrite(noms_zip[k], 1, strlen(noms_zip[k]), z);
        src = fopen(chemins[k], "rb");
        if (!src) {
            free(crcs); free(tailles); free(offsets); fclose(z); return 1;
        }
        while ((lu = fread(tampon, 1, sizeof(tampon), src)) > 0) {
            if (fwrite(tampon, 1, lu, z) != lu) {
                fclose(src);
                free(crcs); free(tailles); free(offsets); fclose(z); return 2;
            }
            taille += (unsigned long)lu;
        }
        fclose(src);
        tailles[k] = taille;
        crcs[k] = crc;
        /* retour patcher crc/csize/usize dans l'en-tete local :
         * signature 4 + version 2 + drapeaux 2 + methode 2 + heure 2 +
         * date 2 = 14 : le crc y vit, puis csize, puis usize. */
        {
            long apres = ftell(z);
            fseek(z, (long)offsets[k] + 14, SEEK_SET);
            ecrire_u32(z, crc);
            ecrire_u32(z, taille);
            ecrire_u32(z, taille);
            fseek(z, apres, SEEK_SET);
        }
    }

    /* repertoire central */
    pos_central = (unsigned long)ftell(z);
    for (k = 0; k < nb; k++) {
        ecrire_u32(z, 0x02014b50UL);
        ecrire_u16(z, 20);            /* version createur */
        ecrire_u16(z, 20);            /* version requise */
        ecrire_u16(z, 0);             /* drapeaux */
        ecrire_u16(z, 0);             /* methode store */
        ecrire_u16(z, 0);             /* heure */
        ecrire_u16(z, 0x21);          /* date */
        ecrire_u32(z, crcs[k]);
        ecrire_u32(z, tailles[k]);
        ecrire_u32(z, tailles[k]);
        ecrire_u16(z, (unsigned int)strlen(noms_zip[k]));
        ecrire_u16(z, 0);             /* extra */
        ecrire_u16(z, 0);             /* commentaire */
        ecrire_u16(z, 0);             /* disque */
        ecrire_u16(z, 0);             /* attributs internes */
        ecrire_u32(z, 0);             /* attributs externes */
        ecrire_u32(z, offsets[k]);
        fwrite(noms_zip[k], 1, strlen(noms_zip[k]), z);
    }
    /* fin de repertoire central — la taille est capturee AVANT d'ecrire
     * l'EOCD (un ftell dans l'argument aurait lu la position APRES les
     * 12 premiers octets de l'EOCD : l'ecart vecu et nomme, 304 vs 292) */
    {
        unsigned long taille_central = (unsigned long)ftell(z) - pos_central;
        ecrire_u32(z, 0x06054b50UL);
        ecrire_u16(z, 0);
        ecrire_u16(z, 0);
        ecrire_u16(z, (unsigned int)nb);
        ecrire_u16(z, (unsigned int)nb);
        ecrire_u32(z, taille_central);
        ecrire_u32(z, pos_central);
        ecrire_u16(z, 0);
    }

    free(crcs); free(tailles); free(offsets);
    if (fclose(z) != 0) return 2;
    return 0;
}

/* ================= extraction + verification ========================= */

static void joindre_chemin(char *dst, size_t taille, const char *dir,
                           const char *nom)
{
    size_t ld = strlen(dir);
    size_t ln = strlen(nom);
    size_t i;
    if (ld + 1 + ln + 1 > taille) { dst[0] = '\0'; return; }
    memcpy(dst, dir, ld);
    dst[ld] = '/';
    memcpy(dst + ld + 1, nom, ln + 1);
    (void)i;   /* separateur '/' : accepte par la CRT Windows ET POSIX */
}

/* mkdir portable : Windows _mkdir, POSIX mkdir. */
#ifdef _WIN32
#include <direct.h>
static int creer_repertoire(const char *chemin) { return _mkdir(chemin); }
#else
#include <sys/stat.h>
#include <sys/types.h>
static int creer_repertoire(const char *chemin)
{
    return mkdir(chemin, 0777);
}
#endif

static void creer_sous_chemins(const char *dir, const char *nom)
{
    char chemin[1024];
    size_t i;
    size_t ln = strlen(nom);
    for (i = 0; i < ln; i++) {
        if (nom[i] == '/') {
            size_t lg = strlen(dir);
            if (lg + 1 + i + 1 >= sizeof(chemin)) return;
            memcpy(chemin, dir, lg);
            chemin[lg] = '/';
            memcpy(chemin + lg + 1, nom, i);
            chemin[lg + 1 + i] = '\0';
            creer_repertoire(chemin);   /* existe deja : erreur ignoree */
        }
    }
}

int extraire_et_verifier(const char *dest_dir)
{
    int verts = 0;
    int i;
    printf("      piece                          octets   sha256 recoupe\n");
    printf("      ------------------------------  -------  ----------------\n");
    creer_repertoire(dest_dir);   /* le dossier du kit lui-meme, d'abord */
    for (i = 0; i < TRIADE_NB_PIECES; i++) {
        const struct piece_kit *p = &TRIADE_MANIFESTE[i];
        char chemin[1024];
        char hex[65];
        FILE *f;
        const unsigned char *donnees = TRIADE_BLOB + p->offset;
        creer_sous_chemins(dest_dir, p->nom);
        joindre_chemin(chemin, sizeof(chemin), dest_dir, p->nom);
        if (!chemin[0]) {
            printf("      %-30s REFUS : chemin trop long\n", p->nom);
            continue;
        }
        f = fopen(chemin, "wb");
        if (!f) {
            printf("      %-30s REFUS : ecriture impossible (%s)\n",
                   p->nom, chemin);
            continue;
        }
        if (fwrite(donnees, 1, (size_t)p->taille, f) != (size_t)p->taille) {
            fclose(f);
            printf("      %-30s REFUS : ecriture incomplete\n", p->nom);
            continue;
        }
        fclose(f);
        sha256_hex(donnees, (size_t)p->taille, hex);
        if (strcmp(hex, p->sha256) == 0) {
            printf("      %-30s %7ld  %s... VERT\n", p->nom, p->taille,
                   hex);
            verts++;
        } else {
            printf("      %-30s %7ld  DIVERGENT : attendu %s..., vecu %s...\n",
                   p->nom, p->taille, p->sha256, hex);
        }
    }
    return verts;
}

/* ========================= DEPOT.txt ================================== */

int construire_depot_txt(const char *chemin, const char *horodatage,
                         int rc_run, const char *nom_zip,
                         const char *argument_n)
{
    FILE *f = fopen(chemin, "wb");
    int i;
    if (!f) return -1;
    fprintf(f, "LE DEPOT DES PREUVES - TRIADE kit-2 dudect, l'exe en 1 clic v2\r\n");
    fprintf(f, "Run : %s (UTC)   code de sortie du lanceur du kit : %d\r\n", horodatage, rc_run);
    if (argument_n && argument_n[0])
        fprintf(f, "N passe au lanceur : %s (defaut 200, minimum 60)\r\n", argument_n);
    fprintf(f, "\r\nOU DEPOSER : le dossier Drive \"Triade\" -> sous-dossier \"test\"\r\n");
    fprintf(f, "(l'exe a ouvert ce dossier dans votre navigateur - deposez %s).\r\n", nom_zip);
    fprintf(f, "\r\nCE QUE CONTIENT CE ZIP :\r\n");
    fprintf(f, "  run-console-<horodatage>.txt   la console ENTIERE du lanceur du kit, telle quelle\r\n");
    fprintf(f, "  journal-dudect-*.csv           le journal de mesure du run (la piece du kit)\r\n");
    fprintf(f, "  sortie-run.txt                 la sortie du mesureur (la piece du kit)\r\n");
    fprintf(f, "  sortie-appel.txt               l'epreuve d'appel FIPS abc (la piece du kit)\r\n");
    fprintf(f, "  temoin-dudect-BROUILLON.txt    le brouillon de temoin auto (le kit l'ecrit)\r\n");
    fprintf(f, "  DEPOT.txt                      le present fichier\r\n");
    fprintf(f, "\r\nLE GESTE QUI RESTE A VOTRE MAIN (le LISEZMOI du kit) : completez le temoin\r\n");
    fprintf(f, "(l'etat EFFECTIF du turbo, vos observations memes defavorables - D189),\r\n");
    fprintf(f, "datez et signez de votre main, puis renvoyez - le labo recoupe et consigne :\r\n");
    fprintf(f, "JAMAIS avant le run, jamais sans pieces.\r\n");
    fprintf(f, "\r\nLE KIT EMBARQUE (octet pour octet le paquet CORRECTIF3 du coffre, %d pieces) :\r\n", TRIADE_NB_PIECES);
    for (i = 0; i < TRIADE_NB_PIECES; i++)
        fprintf(f, "  %s : %s\r\n", TRIADE_MANIFESTE[i].nom, TRIADE_MANIFESTE[i].sha256);
    fprintf(f, "\r\nAucun jeton n'est embarque dans cet exe : le depot au coffre passe par\r\n");
    fprintf(f, "VOTRE geste Drive, jamais par un secret dans le binaire (la frontiere\r\n");
    fprintf(f, "du GUI v1 et de l'APK kit android).\r\n");
    fclose(f);
    return 0;
}

/* ========================= horodatage ================================= */

void horodatage_utc(char *sortie, size_t taille)
{
    time_t t = time(NULL);
    struct tm *tm = gmtime(&t);
    if (tm && taille >= 17) {
        sprintf(sortie, "%04d%02d%02dT%02d%02d%02dZ",
                tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
                tm->tm_hour, tm->tm_min, tm->tm_sec);
    } else if (taille > 0) {
        sortie[0] = '\0';
    }
}
