TRIADE — ÉDITION ACADÉMIQUE v0.13.0 — ARCHIVE COMPLÈTE
======================================================

L'intégralité de la quatrième édition : le manuscrit corrigé ET ses
sources, la spécification v0.13.0 et sa chaîne LaTeX (l'en-tête VERSION
enfin porté v0.13.0), LES PREUVES DES CORRECTIONS (l'audit du benchmark
avec ses sorties brutes, les statistiques recalculées, le rapport de
conformité ligne par ligne), LE KIT DE LA CÉRÉMONIE D183 (l'outil au
partage CF2, l'autotest VERT, le LISEZMOI — préparé, jamais appliqué),
les instruments des éditions v0.11.0/v0.12.0 avec leurs sorties, les
données des quatre éditions, les extraits de journal et les empreintes.

Arborescence :
  README.txt                       ce guide
  manuscrit/                       le PDF + sources + données (macros exactes)
  specification/                   le PDF v0.13.0 + la chaîne spec_v130
  instruments/                     audit_benchmark_v130.py (L'AUDIT),
                                   stats_v130.py (LES STATISTIQUES),
                                   extraire_donnees_v130.py (LE GÉNÉRATEUR
                                   anti-troncature), verifier_edition_v130.py
  instruments/kit_ceremonie_d183/  LE KIT D183 (outil + LISEZMOI + autotest)
  instruments/sorties_v130/        l'audit, les stats, le rapport de conformité
  instruments/sorties_v120/        le modèle formel + le SPRT (v0.12.0)
  instruments/sorties_v110/        les six instruments v0.11.0 + sorties
  journal/                         les extraits + le rejeu intégral
  journal/decisions_D190-D192.md   les décisions des corrections
  journal/entree_226.md            l'entrée du journal
  VERIFICATION_v0.13.0.txt         le constat de vérification
  empreintes_complet.txt           sha-256 de tout ce qui précède

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
