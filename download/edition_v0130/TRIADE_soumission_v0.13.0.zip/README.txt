TRIADE — ÉDITION ACADÉMIQUE v0.13.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers, le maximum exigé) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.13.0.pdf    — le manuscrit IMRAD corrigé (les
     statistiques reformulées : l'IC95 exact de 11/12 et les
     caractéristiques opérationnelles du scellement ; le benchmark AUDITÉ :
     le facteur 15,3 retiré, les chiffres corrigés 75 983 contre 69 132 /
     77 505 ; la règle de comptage opérationnelle ; la neutralité :
     l'anti-debug arbitré, le terrain M7 requalifié, la conséquence D81 au
     modèle de menace ; l'état de l'art étendu — CompCert, LLM Compiler,
     Kitsune/POLUS, SWE-agent, sim-to-real, hardware-in-the-loop) ;
  3. tableaux_donnees_v0.13.0.csv    — TOUS les tableaux des QUATRE
     éditions (v0.10.0 à v0.13.0) — générés, jamais tapés ;
  4. empreintes_soumission.txt       — les empreintes sha-256 ;
  5. VERIFICATION_v0.13.0.txt        — le constat : le rapport de
     conformité ligne par ligne (31 VERT / 0 ROUGE), l'audit du benchmark
     rejoué, les statistiques recalculées, le garde du sceau 14/14, l'audit
     de gouvernance.

Les résultats v0.13.0 (les corrections de l'édition) :
  - le facteur « 15,3× » de v0.11.0 RETIRÉ : un artefact de périmètre (le
    compteur de la finalisation seule, comparé à l'opération complète de
    la référence) — les chiffres corrigés : l'opération complète des
    blocs 75 983 instructions contre 69 132 (gcc -O2) et 77 505 (-Os) ;
    la notation WYSIWYG est COMPÉTITIVE (−9 %/+2 %), plus compacte que
    -O2, moins que -Os ;
  - la cristallisation reformulée : P(sceller|q) = (1-q)^n (3,1 %/0,098 %
    à q = 50 % — 32× plus strict ; 95,1 %/90,4 % à q = 1 %) ; les « α »
    de D189 étaient des rapports de vraisemblance mal étiquetés ;
  - l'IC95 % exact de 11/12 : [0,615 ; 0,998] (Clopper-Pearson, la
    réserve de non-indépendance des itérations séquentielles) ;
  - la neutralité : l'anti-debug léger documenté honnêtement dans les
    deux documents ; le terrain M7 requalifié (qemu TCG au noyau réel —
    fence.i non prouvé sur silicium) ; la conséquence D81 (deux éléments
    trivialement disponibles, le média piège seul rempart) ;
  - le kit de la cérémonie D183 préparé SANS l'appliquer (l'outil au
    partage CF2 D120, l'autotest VERT) — le geste au développeur.

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
