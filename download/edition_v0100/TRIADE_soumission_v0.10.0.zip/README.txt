TRIADE — ÉDITION ACADÉMIQUE v0.10.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers, le maximum exigé) :
  1. README.txt               — le présent guide du relecteur ;
  2. TRIADE_manuscrit_v0.10.0.pdf — le manuscrit IMRAD (anglais, résumé
     français inclus), prêt pour un comité de révision ;
  3. tableaux_donnees_v0.10.0.csv — TOUS les tableaux de données du
     manuscrit (jalons, budgets, oracles, les douze runs Loupe, empreintes),
     générés depuis le journal de travail par scripts/extraire_donnees_v100.py ;
  4. empreintes_soumission.txt  — l'empreinte sha-256 de chaque fichier de
     la présente archive (le manuscrit ET ses données se vérifient) ;
  5. VERIFICATION_v0.10.0.txt   — le constat de l'étape de vérification
     obligatoire : données extraites/vérifiées, artefacts scellés byte pour
     byte, audit de gouvernance VERT, sceau I 14/14.

Comment lire le manuscrit :
  - Chaque valeur numérique des tableaux est EXTRAITE du journal de travail
    append-only (9 348 lignes) et du journal des décisions (D1-D184) par le
    script d'extraction ; le manuscrit n'affirme rien qui ne soit généré.
  - Les quatre questions de recherche : défauts échappés (RQ1), coût en
    tokens par changement validé (RQ2), classes invisibles à l'émulation
    (RQ3), sûreté du patch à chaud (RQ4).
  - Les limites sont explicites : N=1, circularité de l'oracle, absence de
    baseline, sécurité mémoire non prouvée, temps constant non analysé.
  - L'auteur humain est unique ; l'agent IA (Z.ai GLM) est décrit en
    Methods et remercié, jamais co-auteur.

L'archive complète (sources LaTeX, bibliographie, chaîne de spécification,
scripts, extraits de journal) vit dans TRIADE_complet_v0.10.0.zip.

Licence du projet : Business Source License 1.1 (usage hors production
jusqu'au 2028-10-28, puis GPL v3+). Auteur : Alexis Lopez.
