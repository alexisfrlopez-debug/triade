TRIADE — ÉDITION ACADÉMIQUE v0.10.0 — ARCHIVE COMPLÈTE
======================================================

L'intégralité de l'édition : le manuscrit ET ses sources, la spécification
v0.10.0 (l'annexe A portée à sha-256, D184) et sa chaîne LaTeX, les données
GÉNÉRÉES (le script d'extraction refuse si une ancre manque au journal),
l'audit de gouvernance, les extraits de journal cités, les décisions de
l'édition (D182/D183/D184) et les empreintes de tout.

Arborescence :
  README.txt                    le présent guide
  manuscrit/TRIADE_manuscrit_v0.10.0.pdf   le manuscrit (livrable)
  manuscrit/main.tex            sources LaTeX (les tableaux sont \input)
  manuscrit/refs.bib            bibliographie (chaque entrée : DOI vérifiable)
  manuscrit/donnees/            tableaux GÉNÉRÉS (tables_generees.tex + 5 CSV)
  specification/Protocole_TRIADE_v0.10.0_Specification.pdf  la spécification
  specification/spec_v100/      la chaîne LaTeX (née de spec_v090 par copie)
  scripts/extraire_donnees_v100.py   l'extraction + vérification des données
  scripts/audit_gouvernance_v100.py  l'audit de gouvernance (A1-A6)
  scripts/verifier_edition_v100.py   le vérificateur de l'édition
  journal/extraits_journal.txt  les entrées citées par le manuscrit
  journal/decisions_D182-D184.md  les décisions de l'édition
  journal/entree_223.md         l'entrée du journal de travail
  VERIFICATION_v0.10.0.txt      le constat de vérification
  empreintes_complet.txt        sha-256 de tout ce qui précède

Les artefacts scellés ne sont PAS dans l'archive (ils vivent au dépôt) :
leurs empreintes sont consignées dans les données et le constat.

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
