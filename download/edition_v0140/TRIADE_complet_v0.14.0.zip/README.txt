TRIADE — ÉDITION ACADÉMIQUE v0.14.0 — ARCHIVE COMPLÈTE
======================================================

L'intégralité : le manuscrit ET ses sources, la spécification v0.14.0,
LES SIX PREUVES du programme empirique avec leurs sorties brutes (le
plan pré-enregistré, le bras de référence, la re-mesure RQ2,
l'indépendance, le re-jeu des 832), le kit terrain EN ATTENTE, les
données des cinq ères, les extraits, les empreintes.

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
