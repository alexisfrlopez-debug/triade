TRIADE — ÉDITION ACADÉMIQUE v0.14.0 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.14.0.pdf    — le manuscrit : la comparaison
     contrôlée au compilateur (pré-enregistrée : zéro divergence, sha-256
     paritaire à travail égal, la notation testable au même degré), RQ2
     re-mesurée en distributions (580/2 143/3 510 contre la baseline
     naive 300 304 — lecture défavorable consignée), l'indépendance par
     instance isolée (128 constantes, zéro divergence), le re-jeu des
     832 mutants aux composition-killers (93,3 %, tls13/sys à 100 %) ;
  3. tableaux_donnees_v0.14.0.csv    — les tableaux des CINQ ères ;
  4. empreintes_soumission.txt       — les empreintes sha-256 ;
  5. VERIFICATION_v0.14.0.txt        — le constat de vérification.

Licence : Business Source License 1.1. Auteur : Alexis Lopez.
