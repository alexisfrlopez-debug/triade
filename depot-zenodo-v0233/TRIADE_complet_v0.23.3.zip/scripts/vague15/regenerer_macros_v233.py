#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""regenerer_macros_v233.py — LES COMPTES COURANTS des journaux vivants
portés aux macros à la génération v0.23.3 (la release de la vague 15 — la
commande du maître « ok pour la suite (release de la vague etc…) » : LES
CINQ PIÈCES RÉGÉNÉRÉES au linter v2) — les comptes RECALCULÉS des fichiers
mêmes et le DOI au jour de la rédaction [la v0.23.2, le record 24442951],
par remplacements ancrés — REFUS si une ancre manque."""
from __future__ import annotations

import pathlib
import re
import sys

REPO = pathlib.Path(__file__).resolve().parents[2]
OUT = REPO / "edition-v0230" / "donnees" / "macros_v230.tex"

DOI_COURANT = "10.5281/zenodo.24442951"  # la v0.23.2 au jour de la rédaction


def remplace(t: str, ancien: str, nouveau: str, nom: str) -> str:
    if ancien not in t:
        if nouveau in t:
            print(f"  — {nom} (déjà porté)")
            return t
        print(f"ANCRE MANQUANTE : {nom}")
        sys.exit(2)
    if t.count(ancien) != 1:
        print(f"ANCRE AMBIGUE {t.count(ancien)}x : {nom}")
        sys.exit(2)
    print(f"  — {nom}")
    return t.replace(ancien, nouveau)


def main() -> int:
    n_journal = len((REPO / "docs" / "JOURNAL_TRAVAIL.md")
                   .read_text(encoding="utf-8").splitlines())
    n_worklog = len((REPO / "worklog.md")
                    .read_text(encoding="utf-8").splitlines())
    n_decisions = len((REPO / "docs" / "DECISIONS.md")
                      .read_text(encoding="utf-8").splitlines())
    ds = re.findall(r"^## D(\d+)",
                    (REPO / "docs" / "DECISIONS.md").read_text(encoding="utf-8"),
                    re.M)
    plage = f"D1--D{max(int(d) for d in ds)}"
    print(f"les comptes : journal {n_journal:,} · worklog {n_worklog:,} · "
          f"décisions {n_decisions:,} · plage {plage}")

    t = OUT.read_text(encoding="utf-8")

    t = remplace(
        t,
        "\\newcommand{\\nbLignesJournal}{13,650}",
        f"\\newcommand{{\\nbLignesJournal}}{{{n_journal:,}}}",
        f"nbLignesJournal 13,650 → {n_journal:,} (la consignation "
        "automatique des builds D134 — la ligne du build_pdf.sh de la "
        "sync, la génération postérieure à la ligne)")
    t = remplace(
        t,
        "\\newcommand{\\nbLignesWorklog}{14,047}",
        f"\\newcommand{{\\nbLignesWorklog}}{{{n_worklog:,}}}",
        f"nbLignesWorklog 14,047 → {n_worklog:,}")
    t = remplace(
        t,
        "\\newcommand{\\doiVersionCourante}{10.5281/zenodo.24442241}",
        f"\\newcommand{{\\doiVersionCourante}}{{{DOI_COURANT}}}",
        f"doiVersionCourante 24442241 → 24442951 (la v0.23.2 au jour de "
        "la rédaction)")
    # l'en-tête du fichier GÉNÉRÉ porté à la génération courante
    t = remplace(
        t,
        "% Fichier GÉNÉRÉ (v0.23.2) — les comptes EXACTS des journaux",
        "% Fichier GÉNÉRÉ (v0.23.3) — les comptes EXACTS des journaux",
        "l'en-tête du fichier généré (v0.23.3)")
    t = remplace(
        t,
        "% (le worklog et le DOI recalculés par\n"
        "% scripts/vague14/regenerer_macros_v232.py à la génération "
        "corrective v0.23.2 :\n"
        "% les journaux vivants APRÈS la vague 14, la plage à la dernière "
        "décision,\n"
        "% le DOI au jour de la rédaction ; les canons des vagues 9 à 14)",
        "% (le worklog et le DOI recalculés par\n"
        "% scripts/vague15/regenerer_macros_v233.py à la génération "
        "v0.23.3 :\n"
        "% les journaux vivants APRÈS la vague 15, la plage à la dernière "
        "décision,\n"
        "% le DOI au jour de la rédaction ; les canons des vagues 9 à 15)",
        "la note de régénération (v233)")

    OUT.write_text(t, encoding="utf-8")
    print(f"[v233] les macros portées aux comptes courants ({OUT.name})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
