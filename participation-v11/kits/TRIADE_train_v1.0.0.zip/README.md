# TRIADE-TRAIN v1.0.0 — the LLM training pack

This pack carries the material needed to TRAIN a model for TRIADE's native-notation
tasks, separately from the data itself:

- `RECETTES-SFT-DPO-RLVR.md` — family-agnostic recipes: SFT on the green completions,
  DPO on the preference pairs (reward = the judge's verdict, never similarity), RLVR
  with the verifier as oracle; compute budget recorded.
- `dpo-paires.jsonl` — the 48 preference pairs of the corpus v2.1, each pair carrying
  its two sha256 and the contract identifier; splits are watertight by CONTRACT GROUP.
- `DATASET-CARD.json` — the dataset card of the corpus v2.1 (splits, counts, seed 20261126).
- `MANIFESTE.json` — sha256 of every file of this pack.

The DATA (train/dev/test splits, 127/24/19 triples) live in the corpus v2.1 record,
concept DOI 10.5281/zenodo.24457524 (version DOI 10.5281/zenodo.24479882). This pack
does not duplicate them: it depends on them.

Ground rules carried verbatim from the protocol: the judge is the oracle (never a
similarity score); the TEST split contains no golden notation (validators only); the
unique canary stays in TRAIN; every published number is recomputed from its canonical
source. No layer-I artefact, no card, no secret, no personal data.
