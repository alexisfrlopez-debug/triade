TRIADE — ÉDITION ACADÉMIQUE v0.19.5 — ARCHIVE DE SOUMISSION
============================================================

Contenu (cinq fichiers) :
  1. README.txt                      — le présent guide ;
  2. TRIADE_manuscrit_v0.19.5.pdf    — le manuscrit : LA CLÔTURE DE LA VAGUE
     7 (l'instruction 1c4sokpii, la vague 7 cinquième et dernière) : LE
     CRITÈRE D'ÉCHANTILLON du plan D210 clos à N = 7 SANS NOUVEAU TIRAGE
     (sept unités aux deux bras lues du registre, l'amendement conditionnel
     jamais déclenché), LA BATTERIE D'INJECTION DE FAUTES (811/832 tués,
     97,5 % — 83,4 % → 93,3 % → 97,5 %, le reste de 21 nommé à treize
     familles de causes, AUCUN tueur affaibli : la console v0.14.0
     reproduite d'abord), L'INDÉPENDANCE INTER-FAMILLES au GAP NOMMÉ
     (jamais simulée : la confrontation math↔plan tenue, le local 1,5B
     récite 0/64 et copie à la correction, le bras C généré à 1984/2011),
     LE PAQUET D'ÉVALUATION (la reproduction en une commande, la grille
     codée, le protocole du second annotateur pré-enregistré κ ≥ 0,61, le
     calculateur autotesté 3/3) — ET LE STATUT DE GOUVERNANCE PORTÉ À
     L'ÉTAT VÉCU : la cérémonie D183 vécue le 19/11 (l'Entrée 365), la
     phrase commise tournée et l'ancienne refusée, le re-scan de tout
     l'historique trié (dix constats, aucun jeton réel commis), le dépôt
     GitHub PUBLIC (D220) et le DOI vivant portés au statut exact — les
     lignes « prepared and waiting » de la v0.19.4 étaient devenues
     stales à son scellage même, la présente les porte à l'état exact ;
  3. empreintes_livrables.txt        — les sha256 de chaque pièce du dépôt,
     la pièce scellée loupe.exe 0.1.1 et le scellé proxy.exe 1.0.0 compris
     (le registre fait foi) ;
  4. rapport_verification_v0.19.5.txt — la vérification V1--V10 sur pièces
     (le linter v195 29/29 re-roulé, les empreintes du pack 5/5 recoupées,
     les tableaux GÉNÉRÉS des données brutes et confrontés aux consignés,
     la gouvernance à l'état vécu, les écarts nommés) ;
  5. tableaux_donnees_v0.19.5.csv    — les données de la session : la
     batterie d'injection K4 (le global 811/832 et par domaine), le triage
     des 56 survivants au niveau instruction, le reste de 21 nommé à ses
     causes, le registre des livraisons (le comptage N = 7), la grille et
     le codage de l'annotateur 1 — chaque valeur GÉNÉRÉE des registres
     bruts, jamais tapée.

Cette version v0.19.5 succède à la v0.19.4 du même concept DOI : elle porte
l'édition courante à la date du 20/11/2026 (la vague 7 close — les cinq
instructions exécutées). AUCUNE valeur mesurée des éditions scellées
antérieures n'est modifiée — la v0.19.5 est additive.

Licence : Business Source License 1.1 avec Additional Use Grant
académique (peer review, artifact evaluation, réplication scientifique,
recherche non commerciale — la décision D209 ; Change Date 2030-10-28,
conversion GPLv3).
